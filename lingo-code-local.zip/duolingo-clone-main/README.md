# Lingo Code — apprendre à coder (version locale)

Appli façon Duolingo pour apprendre la programmation : **Python**, **JavaScript** et **HTML & CSS**.
Aucun compte, aucune base de données : la progression (points, cœurs, leçons terminées) est
sauvegardée dans le navigateur (localStorage).

## Lancer l'appli

Il faut seulement [Node.js](https://nodejs.org) (version 20 ou plus).

```bash
npm install
npm run dev
```

Puis ouvre http://localhost:3000.

Version « production » : `npm run build` puis `npm start`.

## Contenu des cours

3 cours, 6 unités chacun, 4 leçons par unité : **72 leçons et 528 questions**.

| Cours      | Unités                                                                                                                              |
| ---------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| Python     | Bases · Conditions, boucles, fonctions · Listes, dictionnaires, tuples · Chaînes · Erreurs, modules, compréhensions · Objets (POO)   |
| JavaScript | Bases · Conditions, boucles, tableaux, fonctions · Chaînes et nombres · map/filter/reduce · Objets, JSON, classes · DOM et async     |
| HTML & CSS | Structure HTML · Sélecteurs, boîte, Flexbox · Tableaux, formulaires, sémantique · Grid, responsive · CSS avancé · Accessibilité, SEO |

## Modifier ou ajouter des questions

Le programme est écrit dans :

- [`lib/curriculum.ts`](lib/curriculum.ts) : unités 1 et 2 de chaque cours ;
- [`lib/curriculum-more/`](lib/curriculum-more) : unités 3 à 6 (`python.ts`, `javascript.ts`, `htmlcss.ts`).

Dans ces fichiers :

- `S(question, bonneRéponse, [mauvaise1, mauvaise2])` : question à choix.
- `A([ligne1, ligne2, ...], bonneRéponse, [mauvaises...])` : « Que produit ce code ? ».
- Entoure un passage de `§` pour l'afficher comme du code : `§print()§`.
- L'ordre des réponses est mélangé à chaque leçon.

Ajoute les nouvelles leçons ou unités **à la fin** : les identifiants sont calculés dans
l'ordre, donc insérer au milieu décalerait la progression déjà sauvegardée.

## Remettre la progression à zéro

Bouton « Recommencer à zéro » en bas du menu de gauche.

## Notes

- La progression est propre à chaque navigateur et à chaque appareil.
- La police Nunito est incluse dans le projet : l'appli fonctionne aussi hors ligne.
- Basé sur le projet open source « duolingo-clone » (licence MIT, voir `LICENSE`).
