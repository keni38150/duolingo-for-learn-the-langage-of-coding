"use client";

import { RotateCcw } from "lucide-react";
import { useRouter } from "next/navigation";

import { Button } from "@/components/ui/button";
import { useProgress } from "@/store/use-progress";

export const ResetButton = () => {
  const router = useRouter();
  const reset = useProgress((s) => s.reset);

  const onClick = () => {
    if (!window.confirm("Effacer toute ta progression ?")) return;

    reset();
    router.push("/courses");
  };

  return (
    <Button variant="ghost" className="w-full justify-start" onClick={onClick}>
      <RotateCcw className="mr-3 h-5 w-5" />
      Recommencer à zéro
    </Button>
  );
};
