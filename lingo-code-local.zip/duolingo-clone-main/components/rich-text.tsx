import { Fragment } from "react";

type RichTextProps = {
  text: string;
};

/**
 * Affiche du texte où les passages entourés de § sont rendus comme du code.
 * Exemple : "Quelle fonction affiche du texte ? §print()§"
 */
export const RichText = ({ text }: RichTextProps) => {
  return (
    <>
      {text.split("§").map((part, index) =>
        index % 2 === 1 ? (
          <code
            key={index}
            className="rounded-md bg-neutral-100 px-1.5 py-0.5 font-mono text-[0.9em]"
          >
            {part}
          </code>
        ) : (
          <Fragment key={index}>{part}</Fragment>
        )
      )}
    </>
  );
};
