import { A, S, type UnitData } from "../curriculum-helpers";

export const htmlCssMore: UnitData[] = [
  /* ------------------------------------------------------------------ */
  {
    title: "Unité 3",
    description: "HTML avancé : tableaux, formulaires et sémantique",
    lessons: [
      {
        title: "Les tableaux",
        questions: [
          S(`Quelle balise crée un tableau ?`, `§<table>§`, [`§<tab>§`, `§<grid>§`]),
          S(`Quelle balise définit une ligne de tableau ?`, `§<tr>§`, [`§<td>§`, `§<row>§`]),
          S(`Quelle balise définit une cellule de données ?`, `§<td>§`, [`§<th>§`, `§<cell>§`]),
          S(`Quelle balise définit une cellule d'en-tête ?`, `§<th>§`, [`§<thead>§`, `§<tr>§`]),
          S(`Quel attribut fusionne des cellules sur plusieurs colonnes ?`, `§colspan§`, [`§span§`, `§merge§`]),
          A([`<table>`, `  <tr>`, `    <td>A</td>`, `    <td>B</td>`, `  </tr>`, `</table>`], `Un tableau d'une ligne et 2 colonnes`, [`Un tableau de 2 lignes et 1 colonne`, `Une liste à puces`]),
          S(`Quelle balise regroupe les lignes d'en-tête d'un tableau ?`, `§<thead>§`, [`§<header>§`, `§<top>§`]),
          S(`Quelle balise donne un titre à un tableau ?`, `§<caption>§`, [`§<title>§`, `§<label>§`]),
        ],
      },
      {
        title: "Les formulaires",
        questions: [
          S(`Quelle balise crée un formulaire ?`, `§<form>§`, [`§<input>§`, `§<submit>§`]),
          S(`Quelle balise crée un champ de saisie ?`, `§<input>§`, [`§<field>§`, `§<text>§`]),
          S(`Quel attribut définit le type d'un §<input>§ ?`, `§type§`, [`§kind§`, `§mode§`]),
          S(`Quelle balise associe un texte à un champ ?`, `§<label>§`, [`§<caption>§`, `§<name>§`]),
          S(`Quel type d'§<input>§ masque les caractères saisis ?`, `§password§`, [`§secret§`, `§hidden§`]),
          S(`Quel attribut rend un champ obligatoire ?`, `§required§`, [`§mandatory§`, `§needed§`]),
          S(`Quelle balise crée une liste déroulante ?`, `§<select>§`, [`§<dropdown>§`, `§<list>§`]),
          S(`Quel attribut affiche un texte d'aide grisé dans un champ ?`, `§placeholder§`, [`§hint§`, `§help§`]),
        ],
      },
      {
        title: "La sémantique",
        questions: [
          S(`Quelle balise représente l'en-tête d'une page ?`, `§<header>§`, [`§<top>§`, `§<headline>§`]),
          S(`Quelle balise représente un menu de navigation ?`, `§<nav>§`, [`§<menu-bar>§`, `§<links>§`]),
          S(`Quelle balise représente le pied de page ?`, `§<footer>§`, [`§<bottom>§`, `§<end>§`]),
          S(`Quelle balise représente un contenu indépendant (article de blog) ?`, `§<article>§`, [`§<post>§`, `§<item>§`]),
          S(`Quelle balise regroupe un contenu thématique ?`, `§<section>§`, [`§<part>§`, `§<group>§`]),
          S(`Quelle balise convient à un contenu annexe (barre latérale) ?`, `§<aside>§`, [`§<side>§`, `§<extra>§`]),
          S(`Pourquoi préférer les balises sémantiques à des §<div>§ partout ?`, `Elles donnent du sens (accessibilité, référencement)`, [`Elles s'affichent plus vite`, `Elles remplacent le CSS`]),
          S(`Combien de §<h1>§ est-il recommandé d'avoir par page ?`, `Un seul`, [`Au moins dix`, `Aucun`]),
        ],
      },
      {
        title: "Média et en-têtes",
        questions: [
          S(`Quelle balise intègre une vidéo ?`, `§<video>§`, [`§<movie>§`, `§<media>§`]),
          S(`Quelle balise intègre un son ?`, `§<audio>§`, [`§<sound>§`, `§<music>§`]),
          S(`Quel attribut affiche les boutons de lecture d'une vidéo ?`, `§controls§`, [`§buttons§`, `§player§`]),
          S(`Quelle balise intègre une autre page web dans la page ?`, `§<iframe>§`, [`§<embedpage>§`, `§<frame-in>§`]),
          S(`Quelle balise du §<head>§ définit l'encodage des caractères ?`, `§<meta charset="UTF-8">§`, [`§<encoding utf8>§`, `§<charset="UTF-8">§`]),
          S(`Quelle balise lie une feuille de style CSS ?`, `§<link rel="stylesheet" href="style.css">§`, [`§<css src="style.css">§`, `§<style href="style.css">§`]),
          S(`Quelle balise permet d'écrire du CSS directement dans la page ?`, `§<style>§`, [`§<css>§`, `§<design>§`]),
          S(`Quelle balise insère du JavaScript ?`, `§<script>§`, [`§<js>§`, `§<code>§`]),
        ],
      },
    ],
  },
  /* ------------------------------------------------------------------ */
  {
    title: "Unité 4",
    description: "CSS : mise en page et responsive",
    lessons: [
      {
        title: "Display et position",
        questions: [
          S(`Que fait §display: none;§ ?`, `Cache l'élément et retire sa place`, [`Rend l'élément transparent mais garde sa place`, `Supprime le fichier`]),
          S(`Quelle valeur d'§display§ place les éléments côte à côte en gardant largeur et hauteur ?`, `§inline-block§`, [`§inline§`, `§block§`]),
          S(`Quelle valeur de §position§ est celle par défaut ?`, `§static§`, [`§relative§`, `§absolute§`]),
          S(`Un élément §absolute§ se place par rapport…`, `à l'ancêtre positionné le plus proche`, [`toujours à la fenêtre`, `à l'élément suivant`]),
          S(`Quelle valeur de §position§ fixe l'élément à l'écran, même au défilement ?`, `§fixed§`, [`§locked§`, `§pinned§`]),
          S(`Que fait §visibility: hidden;§ ?`, `Cache l'élément mais garde sa place`, [`Retire l'élément du flux`, `Réduit sa taille à zéro`]),
          S(`Quelle propriété contrôle l'empilement des éléments positionnés ?`, `§z-index§`, [`§layer§`, `§stack§`]),
          S(`Quelle valeur d'§display§ fait occuper toute la largeur disponible ?`, `§block§`, [`§inline§`, `§none§`]),
        ],
      },
      {
        title: "Unités et typographie",
        questions: [
          S(`Quelle unité est relative à la taille de police du parent ?`, `§em§`, [`§px§`, `§cm§`]),
          S(`Quelle unité est relative à la taille de police racine ?`, `§rem§`, [`§vh§`, `§pt§`]),
          S(`À quoi correspond §50vw§ ?`, `50 % de la largeur de la fenêtre`, [`50 pixels`, `50 % de la hauteur de la fenêtre`]),
          S(`À quoi correspond §100vh§ ?`, `100 % de la hauteur de la fenêtre`, [`100 pixels`, `100 % de la largeur du parent`]),
          S(`Quelle propriété change la police ?`, `§font-family§`, [`§font-type§`, `§text-font§`]),
          S(`Quelle propriété règle l'espace entre les lignes de texte ?`, `§line-height§`, [`§line-space§`, `§row-gap§`]),
          S(`Quelle propriété souligne ou barre le texte ?`, `§text-decoration§`, [`§text-style§`, `§font-line§`]),
          S(`Quelle déclaration met le texte en majuscules ?`, `§text-transform: uppercase;§`, [`§font-caps: all;§`, `§text-case: upper;§`]),
        ],
      },
      {
        title: "CSS Grid",
        questions: [
          S(`Quelle déclaration active CSS Grid ?`, `§display: grid;§`, [`§grid: on;§`, `§layout: grid;§`]),
          A([`.g {`, `  display: grid;`, `  grid-template-columns: 1fr 1fr 1fr;`, `}`], `3 colonnes de même largeur`, [`3 lignes de même hauteur`, `1 colonne de 3 pixels`]),
          S(`Que signifie l'unité §fr§ ?`, `Une fraction de l'espace disponible`, [`Un nombre de pixels fixes`, `Une taille de police`]),
          S(`Quelle propriété espace les cellules d'une grille ?`, `§gap§`, [`§grid-space§`, `§cell-margin§`]),
          A([`.g {`, `  display: grid;`, `  grid-template-columns: repeat(2, 100px);`, `}`], `2 colonnes de 100 px`, [`100 colonnes de 2 px`, `2 lignes de 100 px`]),
          S(`Quelle déclaration étire un élément sur 2 colonnes ?`, `§grid-column: span 2;§`, [`§column-merge: 2;§`, `§grid-width: 2;§`]),
          S(`Grid est surtout conçu pour…`, `des mises en page en 2 dimensions (lignes et colonnes)`, [`un seul axe uniquement`, `animer des images`]),
          S(`Quelle propriété définit la hauteur des lignes d'une grille ?`, `§grid-template-rows§`, [`§grid-rows-size§`, `§row-template§`]),
        ],
      },
      {
        title: "Responsive design",
        questions: [
          S(`Quelle balise rend une page adaptée aux mobiles ?`, `§<meta name="viewport" content="width=device-width, initial-scale=1">§`, [`§<mobile ready>§`, `§<meta name="mobile">§`]),
          S(`Que sont les media queries ?`, `Des règles CSS appliquées selon la taille ou les caractéristiques de l'écran`, [`Des requêtes vers un serveur`, `Des commentaires CSS`]),
          A([`@media (max-width: 600px) {`, `  body {`, `    background: red;`, `  }`, `}`], `Fond rouge si la fenêtre fait 600 px ou moins`, [`Fond rouge si la fenêtre fait plus de 600 px`, `Fond rouge dans tous les cas`]),
          S(`Que signifie « mobile first » ?`, `On écrit d'abord le CSS mobile, puis on l'enrichit pour les grands écrans`, [`On supprime la version ordinateur`, `On code uniquement en JavaScript`]),
          S(`Quelle règle rend une image fluide dans son conteneur ?`, `§max-width: 100%;§`, [`§width: 100vh;§`, `§fit: container;§`]),
          S(`Quelle unité s'adapte le mieux à la largeur d'un conteneur ?`, `Le pourcentage §%§`, [`§px§`, `§pt§`]),
          S(`Quelle valeur de §flex-wrap§ permet de passer à la ligne ?`, `§wrap§`, [`§break§`, `§multi§`]),
          S(`Quelle fonction CSS limite une valeur entre un minimum et un maximum ?`, `§clamp()§`, [`§limit()§`, `§range()§`]),
        ],
      },
    ],
  },
  /* ------------------------------------------------------------------ */
  {
    title: "Unité 5",
    description: "CSS avancé : sélecteurs, animations et cascade",
    lessons: [
      {
        title: "Sélecteurs avancés",
        questions: [
          S(`Quel sélecteur cible un lien au survol de la souris ?`, `§a:hover§`, [`§a:over§`, `§a:mouse§`]),
          S(`Quel sélecteur cible le premier enfant ?`, `§:first-child§`, [`§:first§`, `§:child(1)§`]),
          S(`Quel sélecteur cible un champ qui a le focus ?`, `§:focus§`, [`§:active-field§`, `§:selected§`]),
          S(`Quel sélecteur ajoute du contenu avant un élément ?`, `§::before§`, [`§::first§`, `§::prepend§`]),
          S(`Quel sélecteur cible un élément sur deux ?`, `§:nth-child(even)§`, [`§:every(2)§`, `§:alt§`]),
          S(`Que cible §div > p§ ?`, `Les §<p>§ enfants directs d'un §<div>§`, [`Tous les §<p>§ dans un §<div>§, à tout niveau`, `Les §<div>§ dans un §<p>§`]),
          S(`Que cible §h1, h2§ ?`, `Les §<h1>§ ET les §<h2>§`, [`Les §<h2>§ à l'intérieur d'un §<h1>§`, `Seulement le premier des deux`]),
          S(`Que cible §div p§ (avec un espace) ?`, `Tous les §<p>§ descendants d'un §<div>§`, [`Les §<p>§ enfants directs seulement`, `Les §<div>§ qui sont dans un §<p>§`]),
        ],
      },
      {
        title: "Transitions et animations",
        questions: [
          S(`Quelle propriété adoucit un changement de style ?`, `§transition§`, [`§smooth§`, `§animate-change§`]),
          A([`button {`, `  transition: background 0.3s;`, `}`, `button:hover {`, `  background: blue;`, `}`], `Le fond devient bleu en douceur sur 0,3 s au survol`, [`Le fond change instantanément`, `Le bouton disparaît`]),
          S(`Quelle règle déclare une animation CSS ?`, `§@keyframes§`, [`§@animate§`, `§@motion§`]),
          S(`Quelle propriété lance une animation déclarée ?`, `§animation§`, [`§motion§`, `§run§`]),
          S(`Quelle propriété déplace, tourne ou redimensionne un élément sans changer la mise en page ?`, `§transform§`, [`§move§`, `§shift§`]),
          S(`Que fait §transform: rotate(90deg);§ ?`, `Tourne l'élément de 90 degrés`, [`Déplace l'élément de 90 px`, `Agrandit l'élément 90 fois`]),
          S(`Quelle valeur de §animation-iteration-count§ répète indéfiniment ?`, `§infinite§`, [`§forever§`, `§loop§`]),
          S(`Quelle propriété règle la transparence ?`, `§opacity§`, [`§alpha§`, `§transparency§`]),
        ],
      },
      {
        title: "Variables et couleurs",
        questions: [
          S(`Comment déclare-t-on une variable CSS ?`, `§--couleur: red;§`, [`§$couleur: red;§`, `§var couleur = red;§`]),
          S(`Comment utilise-t-on la variable §--couleur§ ?`, `§var(--couleur)§`, [`§$(--couleur)§`, `§get(--couleur)§`]),
          S(`Où déclare-t-on souvent les variables globales ?`, `Dans §:root§`, [`Dans §<head>§`, `Dans §body::before§`]),
          S(`Que signifie §rgba(255, 0, 0, 0.5)§ ?`, `Rouge à moitié transparent`, [`Rouge à 5 %`, `Bleu opaque`]),
          S(`Quelle couleur donne §#000000§ ?`, `Noir`, [`Blanc`, `Rouge`]),
          S(`Quelle couleur donne §#ffffff§ ?`, `Blanc`, [`Noir`, `Gris`]),
          S(`Quel format de couleur utilise teinte, saturation et luminosité ?`, `§hsl()§`, [`§rgb()§`, `§hex§`]),
          S(`Comment crée-t-on un dégradé de fond ?`, `§background: linear-gradient(...)§`, [`§background: gradient(...)§`, `§color: gradient(...)§`]),
        ],
      },
      {
        title: "Spécificité et cascade",
        questions: [
          S(`Entre §.btn§ et §#btn§, lequel est le plus spécifique ?`, `§#btn§`, [`§.btn§`, `Ils sont identiques`]),
          S(`Quel est l'ordre de spécificité croissante ?`, `élément, classe, id`, [`id, classe, élément`, `classe, élément, id`]),
          S(`À spécificité égale, quelle règle l'emporte ?`, `La dernière écrite`, [`La première écrite`, `La plus courte`]),
          S(`Que fait §!important§ ?`, `Donne une priorité maximale à la déclaration`, [`Marque la déclaration comme une erreur`, `Commente la ligne`]),
          S(`Que signifie « cascade » dans CSS ?`, `Plusieurs règles peuvent s'appliquer et sont départagées par des priorités`, [`Les éléments tombent vers le bas`, `Un style ne s'applique qu'une seule fois`]),
          S(`Quel style a la priorité la plus haute (hors §!important§) ?`, `Le style en ligne (attribut §style§)`, [`Une règle sur une balise`, `Un style hérité`]),
          S(`Quelle propriété est héritée par défaut ?`, `§color§`, [`§margin§`, `§border§`]),
          S(`Quelle valeur force l'héritage de la valeur du parent ?`, `§inherit§`, [`§parent§`, `§copy§`]),
        ],
      },
    ],
  },
  /* ------------------------------------------------------------------ */
  {
    title: "Unité 6",
    description: "Accessibilité, SEO et bonnes pratiques",
    lessons: [
      {
        title: "Accessibilité",
        questions: [
          S(`Quel attribut décrit une image pour les lecteurs d'écran ?`, `§alt§`, [`§title-img§`, `§label§`]),
          S(`Que signifie « a11y » ?`, `Accessibilité (accessibility)`, [`Accès à l'API`, `Alignement de balises`]),
          S(`Pourquoi associer un §<label>§ à un champ ?`, `Pour que les lecteurs d'écran et le clic identifient le champ`, [`Pour le colorer`, `Pour le cacher`]),
          S(`Quel attribut relie un §<label>§ à un §<input>§ ?`, `§for§ (avec l'§id§ de l'input)`, [`§link§`, `§target§`]),
          S(`Quel contraste garantit une bonne lisibilité ?`, `Un contraste élevé entre texte et fond`, [`Texte gris clair sur fond blanc`, `Texte et fond de même couleur`]),
          S(`Quelle balise faut-il utiliser pour un bouton cliquable ?`, `§<button>§`, [`§<div onclick>§`, `§<span>§`]),
          S(`Quel attribut ARIA indique le rôle d'un élément ?`, `§role§`, [`§aria-type§`, `§kind§`]),
          S(`Comment navigue-t-on sans souris dans une page ?`, `Avec la touche §Tab§`, [`Avec §Ctrl+Z§`, `C'est impossible`]),
        ],
      },
      {
        title: "Méta-données et SEO",
        questions: [
          S(`Où s'affiche le contenu de §<title>§ ?`, `Dans l'onglet du navigateur et les résultats de recherche`, [`Uniquement en bas de page`, `Nulle part`]),
          S(`Quelle balise résume la page pour les moteurs de recherche ?`, `§<meta name="description" content="...">§`, [`§<summary>§`, `§<seo>§`]),
          S(`Comment indique-t-on la langue de la page ?`, `§<html lang="fr">§`, [`§<html language="fr">§`, `§<html fr>§`]),
          S(`Pourquoi n'utiliser qu'un seul §<h1>§ ?`, `Il indique le sujet principal de la page`, [`Il est obligatoire pour afficher la page`, `Il accélère le chargement`]),
          S(`À quoi sert le fichier §favicon§ ?`, `À afficher une petite icône dans l'onglet`, [`À stocker les mots de passe`, `À compresser le CSS`]),
          S(`Quel attribut ouvre un lien dans un nouvel onglet ?`, `§target="_blank"§`, [`§open="new"§`, `§tab="new"§`]),
          S(`Quel attribut accompagne §target="_blank"§ pour la sécurité ?`, `§rel="noopener"§`, [`§rel="secure"§`, `§safe="true"§`]),
          S(`Quel format d'image convient aux logos vectoriels ?`, `SVG`, [`BMP`, `TIFF`]),
        ],
      },
      {
        title: "Champs de formulaire",
        questions: [
          S(`Quel type d'§<input>§ valide une adresse e-mail ?`, `§email§`, [`§mail§`, `§address§`]),
          S(`Quel type d'§<input>§ n'accepte que des nombres ?`, `§number§`, [`§digit§`, `§numeric§`]),
          S(`Quel attribut limite la longueur maximale du texte ?`, `§maxlength§`, [`§limit§`, `§max-chars§`]),
          S(`Quel attribut impose un motif (expression régulière) ?`, `§pattern§`, [`§regex§`, `§format§`]),
          S(`Quel type d'§<input>§ ouvre un sélecteur de fichier ?`, `§file§`, [`§upload§`, `§browse§`]),
          S(`Quel type d'§<input>§ crée une case à cocher ?`, `§checkbox§`, [`§check§`, `§tick§`]),
          S(`Quel type d'§<input>§ crée des choix exclusifs ?`, `§radio§`, [`§choice§`, `§option§`]),
          S(`Qu'est-ce qui regroupe plusieurs boutons radio ?`, `Le même attribut §name§`, [`Le même §id§`, `La même §class§`]),
        ],
      },
      {
        title: "Bonnes pratiques CSS",
        questions: [
          S(`Pourquoi éviter le CSS en ligne (attribut §style§) ?`, `Il mélange style et structure et se réutilise mal`, [`Il ne marche pas dans les navigateurs`, `Il est interdit`]),
          S(`Que fait §box-sizing: border-box;§ ?`, `Inclut padding et bordure dans la largeur déclarée`, [`Supprime les bordures`, `Ajoute une marge`]),
          S(`À quoi sert un « reset CSS » ?`, `À homogénéiser les styles par défaut des navigateurs`, [`À effacer la page`, `À recharger le CSS`]),
          S(`Quelle convention de nommage utilise §bloc__element--modificateur§ ?`, `BEM`, [`SEO`, `DOM`]),
          S(`Pourquoi éviter les sélecteurs trop spécifiques ?`, `Ils sont difficiles à surcharger et à maintenir`, [`Ils ralentissent l'ordinateur`, `Ils sont interdits en CSS`]),
          S(`Que fait §margin: 0 auto;§ sur un bloc de largeur fixe ?`, `Il le centre horizontalement`, [`Il le centre verticalement`, `Il le cache`]),
          S(`Quel outil du navigateur inspecte et modifie le CSS en direct ?`, `Les outils de développement (touche §F12§)`, [`Le gestionnaire de tâches`, `L'éditeur de registre`]),
          S(`Pourquoi minifier le CSS et le JS en production ?`, `Réduire la taille des fichiers et accélérer le chargement`, [`Corriger les bugs`, `Ajouter des commentaires`]),
        ],
      },
    ],
  },
];
