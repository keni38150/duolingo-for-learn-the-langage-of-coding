import { A, S, type UnitData } from "../curriculum-helpers";

export const pythonMore: UnitData[] = [
  /* ------------------------------------------------------------------ */
  {
    title: "Unité 3",
    description: "Listes, dictionnaires, tuples et ensembles",
    lessons: [
      {
        title: "Les listes",
        questions: [
          S(`Quelle syntaxe crée une liste ?`, `§[1, 2, 3]§`, [`§(1, 2, 3)§`, `§{1, 2, 3}§`]),
          A([`fruits = ["pomme", "kiwi", "poire"]`, `print(fruits[1])`], `kiwi`, [`pomme`, `poire`]),
          A([`print(len([4, 5, 6, 7]))`], `4`, [`3`, `7`]),
          A([`notes = [10, 12]`, `notes.append(15)`, `print(notes)`], `[10, 12, 15]`, [`[15, 10, 12]`, `[10, 12]`]),
          S(`Quel indice désigne le dernier élément d'une liste ?`, `§-1§`, [`§0§`, `§last§`]),
          A([`l = [1, 2, 3]`, `l[0] = 9`, `print(l)`], `[9, 2, 3]`, [`[1, 2, 3]`, `Une erreur`]),
          S(`Quel est l'indice du premier élément d'une liste ?`, `0`, [`1`, `-1`]),
          A([`print([1, 2] + [3])`], `[1, 2, 3]`, [`[6]`, `Une erreur`]),
        ],
      },
      {
        title: "Méthodes et découpage",
        questions: [
          A([`l = [3, 1, 2]`, `l.sort()`, `print(l)`], `[1, 2, 3]`, [`[3, 2, 1]`, `[3, 1, 2]`]),
          A([`l = [1, 2, 3]`, `l.pop()`, `print(l)`], `[1, 2]`, [`[2, 3]`, `[3]`]),
          A([`print([10, 20, 30, 40][1:3])`], `[20, 30]`, [`[10, 20, 30]`, `[20, 30, 40]`]),
          A([`print([1, 2, 3, 4, 5][:2])`], `[1, 2]`, [`[1, 2, 3]`, `[3, 4, 5]`]),
          S(`Quelle méthode supprime la première occurrence d'une valeur ?`, `§remove()§`, [`§delete()§`, `§discard()§`]),
          A([`l = [1, 2]`, `l.insert(0, 9)`, `print(l)`], `[9, 1, 2]`, [`[1, 2, 9]`, `[1, 9, 2]`]),
          A([`print([5, 6, 7][-1])`], `7`, [`5`, `6`]),
          A([`print(sum([1, 2, 3]))`], `6`, [`123`, `Une erreur`]),
        ],
      },
      {
        title: "Les dictionnaires",
        questions: [
          S(`Quelle syntaxe crée un dictionnaire ?`, `§{"a": 1}§`, [`§["a": 1]§`, `§("a" = 1)§`]),
          A([`d = {"nom": "Ana", "age": 20}`, `print(d["nom"])`], `Ana`, [`nom`, `20`]),
          A([`d = {"a": 1}`, `d["b"] = 2`, `print(d)`], `{'a': 1, 'b': 2}`, [`{'a': 1}`, `{'b': 2}`]),
          A([`d = {"x": 5, "y": 7}`, `print(len(d))`], `2`, [`5`, `12`]),
          S(`Un dictionnaire associe…`, `des clés à des valeurs`, [`des valeurs à des fonctions`, `des lignes à des colonnes`]),
          A([`d = {"a": 1}`, `print("a" in d)`], `True`, [`False`, `1`]),
          A([`d = {"a": 1, "b": 2}`, `for cle in d:`, `    print(cle)`], `a puis b`, [`1 puis 2`, `Une erreur`]),
          A([`d = {"a": 1}`, `print(d.get("z", 0))`], `0`, [`None`, `Une erreur`]),
        ],
      },
      {
        title: "Tuples et ensembles",
        questions: [
          S(`Quelle structure est immuable (non modifiable) ?`, `Le tuple`, [`La liste`, `Le dictionnaire`]),
          S(`Quelle syntaxe crée un tuple ?`, `§(1, 2, 3)§`, [`§[1, 2, 3]§`, `§<1, 2, 3>§`]),
          A([`t = (1, 2, 3)`, `print(t[0])`], `1`, [`3`, `Une erreur`]),
          A([`t = (1, 2)`, `t[0] = 5`], `Une erreur (TypeError)`, [`t vaut (5, 2)`, `t vaut (1, 5)`]),
          A([`print(set([1, 2, 2, 3]))`], `{1, 2, 3}`, [`{1, 2, 2, 3}`, `[1, 2, 3]`]),
          S(`Quelle particularité a un ensemble (§set§) ?`, `Il ne contient aucun doublon`, [`Il garde tous les doublons`, `Il associe des clés à des valeurs`]),
          A([`a, b = (1, 2)`, `print(b)`], `2`, [`1`, `(1, 2)`]),
          A([`print(len({1, 2, 3, 3}))`], `3`, [`4`, `2`]),
        ],
      },
    ],
  },
  /* ------------------------------------------------------------------ */
  {
    title: "Unité 4",
    description: "Maîtriser les chaînes de caractères",
    lessons: [
      {
        title: "Méthodes de chaînes",
        questions: [
          A([`print("python".upper())`], `PYTHON`, [`python`, `Python`]),
          A([`print("[" + " a ".strip() + "]")`], `[a]`, [`[ a ]`, `a`]),
          A([`print("a-b-c".split("-"))`], `['a', 'b', 'c']`, [`a b c`, `['a-b-c']`]),
          A([`print(",".join(["a", "b"]))`], `a,b`, [`a b`, `['a', 'b']`]),
          A([`print("chat".replace("c", "m"))`], `mhat`, [`chat`, `mchat`]),
          A([`print(len("bonjour"))`], `7`, [`6`, `8`]),
          S(`Quelle méthode met la première lettre en majuscule ?`, `§capitalize()§`, [`§initial()§`, `§first()§`]),
          A([`print("Python".lower())`], `python`, [`PYTHON`, `Python`]),
        ],
      },
      {
        title: "Les f-strings",
        questions: [
          A([`nom = "Ana"`, `print(f"Salut {nom}")`], `Salut Ana`, [`Salut {nom}`, `Salut nom`]),
          A([`a = 2`, `print(f"{a + 3}")`], `5`, [`a + 3`, `23`]),
          S(`Quel préfixe active une f-string ?`, `§f§`, [`§s§`, `§$§`]),
          A([`prix = 4.5`, `print(f"{prix:.2f}")`], `4.50`, [`4.5`, `4.500`]),
          A([`print("Age : " + str(20))`], `Age : 20`, [`Une erreur`, `Age : str(20)`]),
          A([`print("Age : " + 20)`], `Une erreur (TypeError)`, [`Age : 20`, `Age : `]),
          A([`x = 3`, `print(f"{x} * 2 = {x * 2}")`], `3 * 2 = 6`, [`x * 2 = 6`, `3 * 2 = x * 2`]),
          A([`print("ab" * 3)`], `ababab`, [`ab3`, `Une erreur`]),
        ],
      },
      {
        title: "Découper une chaîne",
        questions: [
          A([`print("python"[0])`], `p`, [`y`, `python`]),
          A([`print("python"[-1])`], `n`, [`p`, `o`]),
          A([`print("python"[1:4])`], `yth`, [`pyth`, `ytho`]),
          A([`print("python"[:2])`], `py`, [`pyt`, `th`]),
          A([`print("python"[2:])`], `thon`, [`tho`, `pyth`]),
          A([`print("abc"[::-1])`], `cba`, [`abc`, `bca`]),
          A([`print("bonjour"[3])`], `j`, [`n`, `o`]),
          S(`Peut-on modifier une lettre d'une chaîne en place (§s[0] = "x"§) ?`, `Non, les chaînes sont immuables`, [`Oui, toujours`, `Seulement si elles sont courtes`]),
        ],
      },
      {
        title: "Entrées et conversions",
        questions: [
          S(`Quelle fonction lit ce que tape l'utilisateur ?`, `§input()§`, [`§read()§`, `§scan()§`]),
          S(`Quel type renvoie toujours §input()§ ?`, `§str§`, [`§int§`, `§float§`]),
          A([`n = int("7")`, `print(n + 1)`], `8`, [`71`, `Une erreur`]),
          A([`print(float("2.5") * 2)`], `5.0`, [`5`, `2.52.5`]),
          A([`print(int(3.9))`], `3`, [`4`, `3.9`]),
          A([`print(str(12) + "3")`], `123`, [`15`, `Une erreur`]),
          A([`print(round(2.6))`], `3`, [`2`, `2.6`]),
          A([`print(bool(0))`], `False`, [`True`, `0`]),
        ],
      },
    ],
  },
  /* ------------------------------------------------------------------ */
  {
    title: "Unité 5",
    description: "Erreurs, modules, logique et compréhensions",
    lessons: [
      {
        title: "Gérer les erreurs",
        questions: [
          S(`Quels blocs permettent d'intercepter une erreur ?`, `§try§ / §except§`, [`§if§ / §else§`, `§for§ / §while§`]),
          A([`try:`, `    print(1 / 0)`, `except ZeroDivisionError:`, `    print("oups")`], `oups`, [`Une erreur plante le programme`, `0`]),
          A([`try:`, `    int("abc")`, `except ValueError:`, `    print("invalide")`], `invalide`, [`abc`, `Rien`]),
          S(`Que se passe-t-il quand §1 / 0§ est exécuté ?`, `Python lève une §ZeroDivisionError§`, [`Le résultat est 0`, `Le résultat est §None§`]),
          A([`try:`, `    print("A")`, `except:`, `    print("B")`, `finally:`, `    print("C")`], `A puis C`, [`A puis B`, `B puis C`]),
          S(`Quel mot-clé lève volontairement une erreur ?`, `§raise§`, [`§throw§`, `§error§`]),
          A([`liste = [1, 2]`, `try:`, `    print(liste[5])`, `except IndexError:`, `    print("hors limites")`], `hors limites`, [`None`, `5`]),
          S(`Quand s'exécute le bloc §finally§ ?`, `Toujours, qu'il y ait une erreur ou non`, [`Seulement s'il y a une erreur`, `Seulement s'il n'y a pas d'erreur`]),
        ],
      },
      {
        title: "Les modules",
        questions: [
          S(`Quel mot-clé permet d'utiliser un module ?`, `§import§`, [`§include§`, `§using§`]),
          A([`import math`, `print(math.sqrt(16))`], `4.0`, [`4`, `16`]),
          A([`import math`, `print(math.pi > 3)`], `True`, [`False`, `3`]),
          S(`Quel module fournit des nombres aléatoires ?`, `§random§`, [`§chance§`, `§dice§`]),
          A([`from math import floor`, `print(floor(2.9))`], `2`, [`3`, `2.9`]),
          A([`import random`, `print(random.randint(5, 5))`], `5`, [`Un nombre entre 0 et 5`, `Une erreur`]),
          S(`Que fait §from math import pi§ ?`, `Importe seulement §pi§ depuis le module §math§`, [`Renomme le module §math§ en §pi§`, `Installe §pi§ depuis internet`]),
          A([`import math`, `print(math.ceil(2.1))`], `3`, [`2`, `2.1`]),
        ],
      },
      {
        title: "Logique et appartenance",
        questions: [
          A([`print(True and False)`], `False`, [`True`, `None`]),
          A([`print(True or False)`], `True`, [`False`, `Une erreur`]),
          A([`print(not True)`], `False`, [`True`, `not True`]),
          A([`print(3 in [1, 2, 3])`], `True`, [`False`, `3`]),
          A([`print("a" in "banane")`], `True`, [`False`, `Une erreur`]),
          A([`print(5 > 3 and 2 > 4)`], `False`, [`True`, `5`]),
          A([`print(1 < 2 < 3)`], `True`, [`False`, `Une erreur`]),
          A([`print(10 != 10)`], `False`, [`True`, `10`]),
        ],
      },
      {
        title: "Compréhensions et fonctions utiles",
        questions: [
          A([`print([x * 2 for x in [1, 2, 3]])`], `[2, 4, 6]`, [`[1, 2, 3]`, `[1, 4, 9]`]),
          A([`print([n for n in range(5) if n % 2 == 0])`], `[0, 2, 4]`, [`[1, 3]`, `[0, 1, 2, 3, 4]`]),
          A([`print([c.upper() for c in "ab"])`], `['A', 'B']`, [`AB`, `['ab']`]),
          A([`print(list(range(3)))`], `[0, 1, 2]`, [`[1, 2, 3]`, `range(3)`]),
          A([`print([i * i for i in range(4)])`], `[0, 1, 4, 9]`, [`[1, 4, 9, 16]`, `[0, 2, 4, 6]`]),
          A([`print(sorted([3, 1, 2]))`], `[1, 2, 3]`, [`[3, 2, 1]`, `None`]),
          A([`print(max([4, 9, 2]))`], `9`, [`4`, `2`]),
          A([`print(min(4, 9, 2))`], `2`, [`9`, `4`]),
        ],
      },
    ],
  },
  /* ------------------------------------------------------------------ */
  {
    title: "Unité 6",
    description: "Programmation orientée objet",
    lessons: [
      {
        title: "Classes et objets",
        questions: [
          S(`Quel mot-clé définit une classe ?`, `§class§`, [`§object§`, `§def§`]),
          S(`Qu'est-ce qu'un objet ?`, `Une instance d'une classe`, [`Un type de commentaire`, `Une boucle spéciale`]),
          A([`class Chat:`, `    pass`, ``, `c = Chat()`, `print(type(c).__name__)`], `Chat`, [`c`, `class`]),
          S(`Comment crée-t-on un objet de la classe §Chat§ ?`, `§Chat()§`, [`§new Chat()§`, `§create Chat§`]),
          A([`class A:`, `    x = 5`, ``, `print(A.x)`], `5`, [`x`, `Une erreur`]),
          S(`Par convention, un nom de classe commence par…`, `une majuscule`, [`un underscore`, `un chiffre`]),
          A([`class Point:`, `    pass`, ``, `p = Point()`, `p.x = 3`, `print(p.x)`], `3`, [`Une erreur`, `x`]),
          S(`À quoi servent les classes ?`, `À regrouper des données et des fonctions dans un même modèle`, [`À accélérer les boucles`, `À remplacer les variables`]),
        ],
      },
      {
        title: "Constructeur et attributs",
        questions: [
          S(`Quelle méthode s'exécute à la création d'un objet ?`, `§__init__§`, [`§__start__§`, `§__create__§`]),
          A([`class P:`, `    def __init__(self, nom):`, `        self.nom = nom`, ``, `p = P("Ana")`, `print(p.nom)`], `Ana`, [`nom`, `self`]),
          S(`À quoi correspond §self§ ?`, `À l'objet courant`, [`À la classe parente`, `À un module`]),
          A([`class C:`, `    def __init__(self):`, `        self.n = 0`, ``, `c = C()`, `c.n += 2`, `print(c.n)`], `2`, [`0`, `Une erreur`]),
          A([`class Voiture:`, `    def __init__(self, vitesse):`, `        self.vitesse = vitesse`, ``, `a = Voiture(50)`, `b = Voiture(80)`, `print(a.vitesse + b.vitesse)`], `130`, [`50`, `80`]),
          S(`Qu'est-ce qu'un attribut ?`, `Une variable qui appartient à un objet`, [`Une fonction globale`, `Un module`]),
          S(`Comment accède-t-on à l'attribut §nom§ d'un objet §p§ ?`, `§p.nom§`, [`§p->nom§`, `§p[nom]§`]),
          A([`class P:`, `    def __init__(self, a, b=10):`, `        self.total = a + b`, ``, `print(P(5).total)`], `15`, [`5`, `10`]),
        ],
      },
      {
        title: "Les méthodes",
        questions: [
          A([`class Chien:`, `    def aboyer(self):`, `        print("Ouaf")`, ``, `Chien().aboyer()`], `Ouaf`, [`Rien`, `Une erreur`]),
          S(`Qu'est-ce qu'une méthode ?`, `Une fonction définie dans une classe`, [`Une variable globale`, `Une boucle`]),
          A([`class Compteur:`, `    def __init__(self):`, `        self.n = 0`, `    def inc(self):`, `        self.n += 1`, ``, `c = Compteur()`, `c.inc()`, `c.inc()`, `print(c.n)`], `2`, [`0`, `1`]),
          A([`class R:`, `    def __init__(self, l, h):`, `        self.l = l`, `        self.h = h`, `    def aire(self):`, `        return self.l * self.h`, ``, `print(R(3, 4).aire())`], `12`, [`7`, `34`]),
          S(`Quel est le premier paramètre d'une méthode d'instance ?`, `§self§`, [`§this§`, `§obj§`]),
          A([`class A:`, `    def dire(self, mot):`, `        return mot + "!"`, ``, `print(A().dire("Hey"))`], `Hey!`, [`Hey`, `!`]),
          A([`class S:`, `    def __str__(self):`, `        return "objet S"`, ``, `print(S())`], `objet S`, [`<S object>`, `Une erreur`]),
          S(`À quoi sert §__str__§ ?`, `À définir le texte affiché par §print()§`, [`À supprimer l'objet`, `À importer un module`]),
        ],
      },
      {
        title: "L'héritage",
        questions: [
          S(`Comment une classe §Chien§ hérite-t-elle de §Animal§ ?`, `§class Chien(Animal):§`, [`§class Chien from Animal:§`, `§class Chien extends Animal:§`]),
          A([`class Animal:`, `    def parler(self):`, `        print("...")`, ``, `class Chien(Animal):`, `    pass`, ``, `Chien().parler()`], `...`, [`Rien`, `Une erreur`]),
          A([`class A:`, `    def f(self):`, `        return "A"`, ``, `class B(A):`, `    def f(self):`, `        return "B"`, ``, `print(B().f())`], `B`, [`A`, `AB`]),
          S(`Redéfinir une méthode héritée, c'est…`, `la réécrire dans la classe enfant`, [`la supprimer de la classe parente`, `la copier dans un module`]),
          S(`Que permet §super()§ ?`, `Accéder à la classe parente`, [`Copier l'objet`, `Importer le module courant`]),
          A([`class A:`, `    def __init__(self):`, `        self.x = 1`, ``, `class B(A):`, `    def __init__(self):`, `        super().__init__()`, `        self.y = 2`, ``, `b = B()`, `print(b.x + b.y)`], `3`, [`2`, `1`]),
          A([`class A:`, `    pass`, ``, `class B(A):`, `    pass`, ``, `print(isinstance(B(), A))`], `True`, [`False`, `Une erreur`]),
          S(`Un avantage de l'héritage est…`, `de réutiliser du code existant`, [`de supprimer les erreurs automatiquement`, `de rendre le programme plus rapide`]),
        ],
      },
    ],
  },
];
