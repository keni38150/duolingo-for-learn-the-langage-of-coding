import { A, S, type UnitData } from "../curriculum-helpers";

export const javascriptMore: UnitData[] = [
  /* ------------------------------------------------------------------ */
  {
    title: "Unité 3",
    description: "Chaînes, nombres et conversions",
    lessons: [
      {
        title: "Méthodes de chaînes",
        questions: [
          A([`console.log("hello".toUpperCase());`], `HELLO`, [`hello`, `Hello`]),
          A([`console.log("hello".length);`], `5`, [`4`, `6`]),
          A([`console.log("abc".charAt(1));`], `b`, [`a`, `c`]),
          A([`console.log("a,b,c".split(","));`], `[ 'a', 'b', 'c' ]`, [`a,b,c`, `[ 'a,b,c' ]`]),
          A([`console.log("chat".replace("c", "m"));`], `mhat`, [`chat`, `mchat`]),
          A([`console.log("[" + " hi ".trim() + "]");`], `[hi]`, [`[ hi ]`, `hi`]),
          A([`console.log("javascript".slice(0, 4));`], `java`, [`javas`, `avas`]),
          A([`console.log("banane".indexOf("n"));`], `2`, [`1`, `3`]),
        ],
      },
      {
        title: "Les template literals",
        questions: [
          S(`Quels caractères délimitent une template literal ?`, `Les accents graves (backticks)`, [`Les guillemets simples`, `Les parenthèses`]),
          A([`const nom = "Ana";`, 'console.log(`Salut ${nom}`);'], `Salut Ana`, [`Salut \${nom}`, `Salut nom`]),
          A(['console.log(`${2 + 3}`);'], `5`, [`2 + 3`, `23`]),
          A([`const a = 4;`, 'console.log(`a vaut ${a}`);'], `a vaut 4`, [`a vaut a`, `a vaut \${a}`]),
          S(`Les template literals permettent…`, `d'insérer des expressions dans du texte`, [`de déclarer des constantes`, `de créer des tableaux`]),
          A([`console.log("a" + 1 + 2);`], `a12`, [`a3`, `3a`]),
          A([`console.log(1 + 2 + "a");`], `3a`, [`12a`, `a3`]),
          A([`console.log("ab".repeat(3));`], `ababab`, [`ab3`, `abab`]),
        ],
      },
      {
        title: "Math et nombres",
        questions: [
          A([`console.log(Math.max(3, 9, 5));`], `9`, [`3`, `5`]),
          A([`console.log(Math.round(2.5));`], `3`, [`2`, `2.5`]),
          A([`console.log(Math.floor(2.9));`], `2`, [`3`, `2.9`]),
          A([`console.log(Math.ceil(2.1));`], `3`, [`2`, `2.1`]),
          A([`console.log(Math.abs(-7));`], `7`, [`-7`, `0`]),
          S(`Que renvoie §Math.random()§ ?`, `Un décimal entre 0 (inclus) et 1 (exclu)`, [`Un entier entre 1 et 10`, `Toujours 0 ou 1`]),
          A([`console.log(Math.pow(2, 4));`], `16`, [`8`, `6`]),
          A([`console.log(Math.sqrt(49));`], `7`, [`24.5`, `49`]),
        ],
      },
      {
        title: "Conversions et pièges",
        questions: [
          A([`console.log(Number("42") + 1);`], `43`, [`421`, `NaN`]),
          A([`console.log(parseInt("12px"));`], `12`, [`NaN`, `12px`]),
          A([`console.log(Number("abc"));`], `NaN`, [`0`, `Une erreur`]),
          A([`console.log(String(5) + 1);`], `51`, [`6`, `NaN`]),
          A([`console.log(typeof NaN);`], `number`, [`NaN`, `undefined`]),
          A([`console.log(Boolean(""));`], `false`, [`true`, `undefined`]),
          A([`console.log(parseFloat("3.14abc"));`], `3.14`, [`NaN`, `3`]),
          A([`console.log(0.1 + 0.2 === 0.3);`], `false`, [`true`, `Une erreur`]),
        ],
      },
    ],
  },
  /* ------------------------------------------------------------------ */
  {
    title: "Unité 4",
    description: "Méthodes avancées sur les tableaux",
    lessons: [
      {
        title: "map, filter et forEach",
        questions: [
          A([`console.log([1, 2, 3].map(x => x * 2));`], `[ 2, 4, 6 ]`, [`[ 1, 2, 3 ]`, `12`]),
          A([`console.log([1, 2, 3, 4].filter(x => x % 2 === 0));`], `[ 2, 4 ]`, [`[ 1, 3 ]`, `[ 1, 2, 3, 4 ]`]),
          S(`Que fait §map()§ ?`, `Crée un nouveau tableau en transformant chaque élément`, [`Supprime des éléments`, `Trie le tableau`]),
          S(`Que fait §filter()§ ?`, `Garde seulement les éléments qui passent le test`, [`Transforme chaque élément`, `Ajoute un élément`]),
          A([`console.log(["a", "b"].map(s => s.toUpperCase()));`], `[ 'A', 'B' ]`, [`[ 'a', 'b' ]`, `AB`]),
          A([`console.log([5, 12, 8].filter(n => n > 6));`], `[ 12, 8 ]`, [`[ 5 ]`, `[ 5, 12, 8 ]`]),
          A([`[1, 2, 3].forEach(n => console.log(n * 10));`], `10 puis 20 puis 30`, [`1 puis 2 puis 3`, `60`]),
          A([`const t = [1, 2, 3];`, `const u = t.map(x => x + 1);`, `console.log(t);`], `[ 1, 2, 3 ]`, [`[ 2, 3, 4 ]`, `undefined`]),
        ],
      },
      {
        title: "reduce, find, some, every",
        questions: [
          A([`console.log([1, 2, 3, 4].reduce((a, b) => a + b, 0));`], `10`, [`24`, `4`]),
          A([`console.log([4, 8, 15].find(n => n > 5));`], `8`, [`15`, `[ 8, 15 ]`]),
          A([`console.log([1, 2, 3].some(n => n > 2));`], `true`, [`false`, `3`]),
          A([`console.log([1, 2, 3].every(n => n > 1));`], `false`, [`true`, `2`]),
          A([`console.log([1, 2, 3].includes(2));`], `true`, [`false`, `1`]),
          A([`console.log([5, 6, 7].indexOf(7));`], `2`, [`7`, `-1`]),
          A([`console.log([1, 2, 3].find(n => n > 10));`], `undefined`, [`null`, `-1`]),
          A([`console.log([2, 3, 4].reduce((a, b) => a * b, 1));`], `24`, [`9`, `1`]),
        ],
      },
      {
        title: "slice, splice, sort, join",
        questions: [
          A([`console.log([1, 2, 3, 4].slice(1, 3));`], `[ 2, 3 ]`, [`[ 1, 2, 3 ]`, `[ 2, 3, 4 ]`]),
          A([`console.log(["a", "b", "c"].join("-"));`], `a-b-c`, [`a,b,c`, `abc`]),
          A([`const t = [3, 1, 2];`, `t.sort();`, `console.log(t);`], `[ 1, 2, 3 ]`, [`[ 3, 2, 1 ]`, `[ 3, 1, 2 ]`]),
          A([`console.log([10, 9, 1].sort());`], `[ 1, 10, 9 ]`, [`[ 1, 9, 10 ]`, `[ 10, 9, 1 ]`]),
          A([`const t = [1, 2, 3];`, `t.pop();`, `console.log(t);`], `[ 1, 2 ]`, [`[ 2, 3 ]`, `[ 3 ]`]),
          A([`const t = [1, 2];`, `t.unshift(0);`, `console.log(t);`], `[ 0, 1, 2 ]`, [`[ 1, 2, 0 ]`, `[ 1, 2 ]`]),
          A([`const t = [1, 2, 3];`, `t.splice(1, 1);`, `console.log(t);`], `[ 1, 3 ]`, [`[ 1, 2 ]`, `[ 2, 3 ]`]),
          A([`console.log([1, 2, 3].reverse());`], `[ 3, 2, 1 ]`, [`[ 1, 2, 3 ]`, `[ 2, 1, 3 ]`]),
        ],
      },
      {
        title: "Déstructuration et spread",
        questions: [
          A([`const [a, b] = [10, 20];`, `console.log(b);`], `20`, [`10`, `[ 10, 20 ]`]),
          A([`const { nom } = { nom: "Ana", age: 20 };`, `console.log(nom);`], `Ana`, [`nom`, `20`]),
          A([`const a = [1, 2];`, `const b = [...a, 3];`, `console.log(b);`], `[ 1, 2, 3 ]`, [`[ [ 1, 2 ], 3 ]`, `[ 3, 1, 2 ]`]),
          S(`À quoi sert l'opérateur §...§ (spread) ?`, `À « déplier » un tableau ou un objet`, [`À commenter du code`, `À répéter une boucle`]),
          A([`const [x, ...reste] = [1, 2, 3];`, `console.log(reste);`], `[ 2, 3 ]`, [`[ 1 ]`, `[ 1, 2, 3 ]`]),
          A([`function nb(...n) {`, `  return n.length;`, `}`, `console.log(nb(5, 6, 7));`], `3`, [`18`, `5`]),
          A([`const o = { a: 1 };`, `const p = { ...o, b: 2 };`, `console.log(p);`], `{ a: 1, b: 2 }`, [`{ a: 1 }`, `{ b: 2 }`]),
          A([`let [a, b] = [1, 2];`, `[a, b] = [b, a];`, `console.log(a);`], `2`, [`1`, `undefined`]),
        ],
      },
    ],
  },
  /* ------------------------------------------------------------------ */
  {
    title: "Unité 5",
    description: "Objets, JSON et classes",
    lessons: [
      {
        title: "Les objets",
        questions: [
          S(`Quelle syntaxe crée un objet ?`, `§{ nom: "Ana" }§`, [`§[ nom: "Ana" ]§`, `§( nom = "Ana" )§`]),
          A([`const p = { nom: "Ana", age: 20 };`, `console.log(p.nom);`], `Ana`, [`nom`, `20`]),
          A([`const p = { a: 1 };`, `p.b = 2;`, `console.log(p);`], `{ a: 1, b: 2 }`, [`{ a: 1 }`, `Une erreur`]),
          A([`const p = { x: 5 };`, `console.log(p["x"]);`], `5`, [`x`, `undefined`]),
          A([`console.log(Object.keys({ a: 1, b: 2 }));`], `[ 'a', 'b' ]`, [`[ 1, 2 ]`, `{ a: 1, b: 2 }`]),
          A([`const p = { a: 1 };`, `delete p.a;`, `console.log(p);`], `{}`, [`{ a: 1 }`, `undefined`]),
          A([`console.log("a" in { a: 1 });`], `true`, [`false`, `1`]),
          A([`const o = { n: 1 };`, `console.log(o.z);`], `undefined`, [`null`, `Une erreur`]),
        ],
      },
      {
        title: "Méthodes et this",
        questions: [
          A([`const o = {`, `  dire() {`, `    return "salut";`, `  },`, `};`, `console.log(o.dire());`], `salut`, [`dire`, `undefined`]),
          A([`const o = {`, `  n: 5,`, `  double() {`, `    return this.n * 2;`, `  },`, `};`, `console.log(o.double());`], `10`, [`5`, `NaN`]),
          S(`Dans une méthode d'objet, §this§ désigne…`, `l'objet qui appelle la méthode`, [`toujours la page web`, `le dernier tableau créé`]),
          A([`for (const cle in { a: 1, b: 2 }) {`, `  console.log(cle);`, `}`], `a puis b`, [`1 puis 2`, `{ a: 1, b: 2 }`]),
          A([`console.log(Object.values({ x: 10, y: 20 }));`], `[ 10, 20 ]`, [`[ 'x', 'y' ]`, `30`]),
          A([`const o = { a: 1, b: 2 };`, `for (const [k, v] of Object.entries(o)) {`, `  console.log(k + v);`, `}`], `a1 puis b2`, [`a puis b`, `3`]),
          A([`const a = { n: 1 };`, `const b = a;`, `b.n = 9;`, `console.log(a.n);`], `9`, [`1`, `undefined`]),
          A([`console.log(typeof {});`], `object`, [`array`, `dictionary`]),
        ],
      },
      {
        title: "JSON",
        questions: [
          A([`console.log(JSON.stringify({ a: 1 }));`], `{"a":1}`, [`{ a: 1 }`, `a:1`]),
          A([`console.log(JSON.parse('{"a": 2}').a);`], `2`, [`a`, `{"a": 2}`]),
          S(`Que signifie JSON ?`, `JavaScript Object Notation`, [`Java Standard Object Network`, `JavaScript Online Node`]),
          S(`Dans du JSON, les clés doivent être…`, `entre guillemets doubles`, [`sans guillemets`, `entre guillemets simples`]),
          A([`console.log(JSON.stringify([1, 2]));`], `[1,2]`, [`[ 1, 2 ]`, `"1,2"`]),
          A([`console.log(typeof JSON.stringify({}));`], `string`, [`object`, `json`]),
          A([`const o = JSON.parse("[1,2,3]");`, `console.log(o.length);`], `3`, [`7`, `1`]),
          S(`À quoi sert §JSON.stringify§ ?`, `À convertir une valeur en texte JSON`, [`À lire un fichier`, `À trier un tableau`]),
        ],
      },
      {
        title: "Les classes",
        questions: [
          A([`class Chat {`, `  miauler() {`, `    return "miaou";`, `  }`, `}`, `console.log(new Chat().miauler());`], `miaou`, [`Chat`, `Une erreur`]),
          A([`class P {`, `  constructor(nom) {`, `    this.nom = nom;`, `  }`, `}`, `console.log(new P("Ana").nom);`], `Ana`, [`nom`, `undefined`]),
          S(`Quel mot-clé crée une instance de classe ?`, `§new§`, [`§create§`, `§make§`]),
          A([`class A {`, `  constructor() {`, `    this.x = 1;`, `  }`, `}`, `class B extends A {}`, `console.log(new B().x);`], `1`, [`undefined`, `Une erreur`]),
          S(`Quel mot-clé permet à une classe d'hériter d'une autre ?`, `§extends§`, [`§inherits§`, `§from§`]),
          A([`class C {`, `  static hello() {`, `    return "hi";`, `  }`, `}`, `console.log(C.hello());`], `hi`, [`Une erreur`, `undefined`]),
          A([`class A {`, `  f() { return "A"; }`, `}`, `class B extends A {`, `  f() { return "B"; }`, `}`, `console.log(new B().f());`], `B`, [`A`, `AB`]),
          A([`class P {`, `  constructor(a, b) {`, `    this.total = a + b;`, `  }`, `}`, `console.log(new P(2, 3).total);`], `5`, [`23`, `undefined`]),
        ],
      },
    ],
  },
  /* ------------------------------------------------------------------ */
  {
    title: "Unité 6",
    description: "Le DOM, les événements et l'asynchrone",
    lessons: [
      {
        title: "Le DOM",
        questions: [
          S(`Que signifie DOM ?`, `Document Object Model`, [`Data Output Mode`, `Dynamic Order Method`]),
          S(`Quelle méthode sélectionne un élément par son id ?`, `§document.getElementById()§`, [`§document.find()§`, `§document.id()§`]),
          S(`Quelle méthode sélectionne le premier élément correspondant à un sélecteur CSS ?`, `§document.querySelector()§`, [`§document.select()§`, `§document.css()§`]),
          S(`Quelle propriété change le texte d'un élément ?`, `§textContent§`, [`§setText§`, `§content()§`]),
          S(`Quelle propriété modifie le style d'un élément ?`, `§element.style§`, [`§element.css§`, `§element.design§`]),
          S(`Comment ajoute-t-on une classe CSS à un élément ?`, `§element.classList.add("actif")§`, [`§element.addClass("actif")§`, `§element.class += "actif"§`]),
          S(`Quelle méthode crée un nouvel élément HTML ?`, `§document.createElement()§`, [`§document.newElement()§`, `§document.make()§`]),
          S(`Quelle méthode ajoute un enfant à un élément ?`, `§appendChild()§`, [`§addChild()§`, `§insert()§`]),
        ],
      },
      {
        title: "Les événements",
        questions: [
          S(`Quelle méthode écoute un événement ?`, `§addEventListener()§`, [`§listen()§`, `§onEvent()§`]),
          S(`Quel événement se déclenche lors d'un clic ?`, `§"click"§`, [`§"press"§`, `§"tap"§`]),
          S(`Quel événement se déclenche à chaque modification de la valeur d'un champ ?`, `§"input"§`, [`§"type"§`, `§"write"§`]),
          S(`Que représente le paramètre §event§ d'un gestionnaire ?`, `Des informations sur l'événement`, [`Une copie de la page`, `Le serveur`]),
          S(`Que fait §event.preventDefault()§ ?`, `Annule le comportement par défaut (ex. envoi d'un formulaire)`, [`Supprime l'élément`, `Arrête le navigateur`]),
          A([`const bouton = { clics: 0 };`, `bouton.clics++;`, `bouton.clics++;`, `console.log(bouton.clics);`], `2`, [`0`, `1`]),
          S(`Où place-t-on §<script>§ pour que le DOM soit déjà chargé ?`, `À la fin de §<body>§ (ou avec §defer§)`, [`Dans §<title>§`, `Avant §<html>§`]),
          S(`Que fait §element.remove()§ ?`, `Supprime l'élément de la page`, [`Cache l'élément seulement`, `Vide son texte`]),
        ],
      },
      {
        title: "Timers et callbacks",
        questions: [
          A([`setTimeout(() => console.log("B"), 0);`, `console.log("A");`], `A puis B`, [`B puis A`, `A seulement`]),
          S(`Que fait §setTimeout(f, 1000)§ ?`, `Exécute §f§ après 1 seconde`, [`Exécute §f§ toutes les secondes`, `Exécute §f§ 1000 fois`]),
          S(`Que fait §setInterval(f, 1000)§ ?`, `Exécute §f§ toutes les secondes`, [`Exécute §f§ une seule fois`, `Attend 1000 secondes`]),
          S(`Quelle fonction arrête un §setInterval§ ?`, `§clearInterval()§`, [`§stopInterval()§`, `§break()§`]),
          S(`Qu'est-ce qu'un callback ?`, `Une fonction passée en argument à une autre fonction`, [`Une erreur de syntaxe`, `Un type de boucle`]),
          A([`function appeler(cb) {`, `  cb("salut");`, `}`, `appeler(m => console.log(m));`], `salut`, [`cb`, `Une erreur`]),
          A([`console.log("1");`, `setTimeout(() => console.log("2"), 100);`, `console.log("3");`], `1 puis 3 puis 2`, [`1 puis 2 puis 3`, `3 puis 2 puis 1`]),
          S(`JavaScript est-il mono-thread (un seul fil d'exécution) ?`, `Oui, avec une file d'événements pour l'asynchrone`, [`Non, il exécute toujours plusieurs fils`, `Oui, donc il ne peut rien faire en asynchrone`]),
        ],
      },
      {
        title: "Promises et async/await",
        questions: [
          S(`Que représente une Promise ?`, `Une valeur qui sera disponible plus tard`, [`Une boucle infinie`, `Un type de tableau`]),
          A([`Promise.resolve(5).then(v => console.log(v));`], `5`, [`Promise`, `undefined`]),
          S(`Quel mot-clé permet d'attendre une Promise ?`, `§await§`, [`§wait§`, `§pause§`]),
          S(`Dans quel type de fonction utilise-t-on §await§ (hors module) ?`, `Une fonction §async§`, [`Une fonction fléchée uniquement`, `N'importe quelle fonction`]),
          A([`async function f() {`, `  return 3;`, `}`, `f().then(v => console.log(v));`], `3`, [`Promise`, `Une erreur`]),
          S(`Quelle méthode d'une Promise gère les erreurs ?`, `§catch()§`, [`§error()§`, `§fail()§`]),
          A([`async function f() {`, `  const x = await Promise.resolve(4);`, `  console.log(x * 2);`, `}`, `f();`], `8`, [`4`, `Promise`]),
          S(`Quelle fonction du navigateur récupère des données depuis une URL ?`, `§fetch()§`, [`§get()§`, `§download()§`]),
        ],
      },
    ],
  },
];
