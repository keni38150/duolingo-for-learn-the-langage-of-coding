import { curriculum } from "./curriculum";
import type { Challenge, ChallengeOption, Course, Lesson } from "./types";

export type CatalogLesson = Lesson & { challengeIds: number[] };

export type CatalogUnit = {
  id: number;
  title: string;
  description: string;
  courseId: number;
  order: number;
  lessons: CatalogLesson[];
};

export type CatalogChallenge = Challenge & {
  challengeOptions: ChallengeOption[];
};

export type CatalogLessonWithChallenges = Lesson & {
  challenges: CatalogChallenge[];
};

const courses: Course[] = [];
const units: CatalogUnit[] = [];
const lessonsById = new Map<number, CatalogLessonWithChallenges>();

// Les ids sont générés dans l'ordre du programme : ils restent stables tant
// que tu n'insères pas de contenu AVANT du contenu existant. Ajoute plutôt
// les nouvelles leçons à la fin (sinon la progression sauvegardée sera décalée).
let courseId = 0;
let unitId = 0;
let lessonId = 0;
let challengeId = 0;
let optionId = 0;

for (const courseData of curriculum) {
  const course: Course = {
    id: ++courseId,
    title: courseData.title,
    imageSrc: courseData.imageSrc,
  };
  courses.push(course);

  for (const [unitIndex, unitData] of courseData.units.entries()) {
    const unit: CatalogUnit = {
      id: ++unitId,
      title: unitData.title,
      description: unitData.description,
      courseId: course.id,
      order: unitIndex + 1,
      lessons: [],
    };

    for (const [lessonIndex, lessonData] of unitData.lessons.entries()) {
      const lesson: CatalogLessonWithChallenges = {
        id: ++lessonId,
        title: lessonData.title,
        unitId: unit.id,
        order: lessonIndex + 1,
        challenges: [],
      };

      for (const [questionIndex, question] of lessonData.questions.entries()) {
        const challenge: CatalogChallenge = {
          id: ++challengeId,
          lessonId: lesson.id,
          type: question.type,
          question: question.question,
          order: questionIndex + 1,
          challengeOptions: [],
        };

        const texts = [
          { text: question.correct, correct: true },
          ...question.wrong.map((text) => ({ text, correct: false })),
        ];

        for (const option of texts) {
          challenge.challengeOptions.push({
            id: ++optionId,
            challengeId: challenge.id,
            text: option.text,
            correct: option.correct,
            imageSrc: null,
            audioSrc: null,
          });
        }

        lesson.challenges.push(challenge);
      }

      lessonsById.set(lesson.id, lesson);
      unit.lessons.push({
        id: lesson.id,
        title: lesson.title,
        unitId: lesson.unitId,
        order: lesson.order,
        challengeIds: lesson.challenges.map((c) => c.id),
      });
    }

    units.push(unit);
  }
}

export const getCourses = () => courses;

export const getCourseById = (id: number) =>
  courses.find((course) => course.id === id);

export const getUnitsByCourse = (id: number) =>
  units.filter((unit) => unit.courseId === id);

export const getLessonById = (id: number) => lessonsById.get(id);
