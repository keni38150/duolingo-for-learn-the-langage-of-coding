/** Types et helpers pour écrire le programme (voir curriculum.ts). */

export type Question = {
  type: "SELECT" | "ASSIST";
  question: string;
  correct: string;
  wrong: string[];
};

export type LessonData = { title: string; questions: Question[] };
export type UnitData = {
  title: string;
  description: string;
  lessons: LessonData[];
};
export type CourseData = { title: string; imageSrc: string; units: UnitData[] };

export const S = (question: string, correct: string, wrong: string[]): Question => ({
  type: "SELECT",
  question,
  correct,
  wrong,
});

export const A = (lines: string[], correct: string, wrong: string[]): Question => ({
  type: "ASSIST",
  question: lines.join("\n"),
  correct,
  wrong,
});

