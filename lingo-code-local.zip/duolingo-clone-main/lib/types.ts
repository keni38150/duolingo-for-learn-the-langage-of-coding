export type ChallengeType = "SELECT" | "ASSIST";

export type Course = {
  id: number;
  title: string;
  imageSrc: string;
};

export type Lesson = {
  id: number;
  title: string;
  unitId: number;
  order: number;
};

export type Challenge = {
  id: number;
  lessonId: number;
  type: ChallengeType;
  question: string;
  order: number;
};

export type ChallengeOption = {
  id: number;
  challengeId: number;
  text: string;
  correct: boolean;
  imageSrc: string | null;
  audioSrc: string | null;
};
