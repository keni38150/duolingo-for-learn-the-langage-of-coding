/**
 * Programme des cours de programmation.
 *
 * Convention d'écriture :
 *  - §texte§ affiche `texte` comme du code (police monospace) dans l'interface.
 *  - S(question, bonneReponse, [mauvaises...]) : question à choix (type SELECT).
 *  - A(lignesDeCode, bonneReponse, [mauvaises...]) : "Que produit ce code ?" (type ASSIST).
 *    Les lignes de code sont affichées dans la bulle de la mascotte.
 *  - L'ordre des réponses est mélangé au moment du seed.
 */

import type { CourseData } from "./curriculum-helpers";
import { A, S } from "./curriculum-helpers";
import { htmlCssMore } from "./curriculum-more/htmlcss";
import { javascriptMore } from "./curriculum-more/javascript";
import { pythonMore } from "./curriculum-more/python";

export type { CourseData, LessonData, Question, UnitData } from "./curriculum-helpers";

/* -------------------------------------------------------------------------- */
/*                                   PYTHON                                   */
/* -------------------------------------------------------------------------- */

const python: CourseData = {
  title: "Python",
  imageSrc: "/python.svg",
  units: [
    {
      title: "Unité 1",
      description: "Les bases de Python",
      lessons: [
        {
          title: "Afficher du texte",
          questions: [
            S(
              `Quelle fonction affiche du texte à l'écran en Python ?`,
              `§print()§`,
              [`§echo()§`, `§console.log()§`]
            ),
            A([`print("Salut")`], `Salut`, [`"Salut"`, `Une erreur`]),
            S(
              `Quel symbole commence un commentaire en Python ?`,
              `§#§`,
              [`§//§`, `§<!--§`]
            ),
            A(
              [`# print("A")`, `print("B")`],
              `B`,
              [`A`, `A puis B`]
            ),
            S(
              `Quelle ligne affiche le texte Bonjour ?`,
              `§print("Bonjour")§`,
              [`§print(Bonjour)§`, `§Print("Bonjour")§`]
            ),
            S(
              `Que fait un programme ?`,
              `Il exécute des instructions dans l'ordre`,
              [`Il dessine uniquement des images`, `Il fonctionne sans instructions`]
            ),
          ],
        },
        {
          title: "Les variables",
          questions: [
            S(
              `Qu'est-ce qu'une variable ?`,
              `Un nom qui stocke une valeur`,
              [`Une fonction qui affiche du texte`, `Un type de commentaire`]
            ),
            A([`age = 15`, `print(age)`], `15`, [`age`, `Une erreur`]),
            S(
              `Quelle ligne crée une variable §prenom§ contenant "Léa" ?`,
              `§prenom = "Léa"§`,
              [`§prenom == "Léa"§`, `§"Léa" = prenom§`]
            ),
            A([`x = 3`, `x = 7`, `print(x)`], `7`, [`3`, `10`]),
            S(
              `Quel nom de variable est valide en Python ?`,
              `§mon_score§`,
              [`§2score§`, `§mon-score§`]
            ),
            S(
              `Quel symbole sert à affecter une valeur à une variable ?`,
              `§=§`,
              [`§==§`, `§=>§`]
            ),
          ],
        },
        {
          title: "Les types de données",
          questions: [
            S(`Quel est le type de §42§ ?`, `§int§`, [`§str§`, `§float§`]),
            S(
              `Quel est le type de §"42"§ (avec des guillemets) ?`,
              `§str§`,
              [`§int§`, `§bool§`]
            ),
            A(
              [`print(type(3.14))`],
              `<class 'float'>`,
              [`<class 'int'>`, `<class 'str'>`]
            ),
            S(
              `Quelles valeurs un booléen peut-il prendre en Python ?`,
              `§True§ et §False§`,
              [`§Oui§ et §Non§`, `§true§ et §false§ en minuscules`]
            ),
            A([`print("2" + "3")`], `23`, [`5`, `Une erreur`]),
            S(
              `Quelle expression convertit "5" en nombre entier ?`,
              `§int("5")§`,
              [`§str("5")§`, `§bool("5")§`]
            ),
          ],
        },
        {
          title: "Les opérations",
          questions: [
            A([`print(2 + 3 * 4)`], `14`, [`20`, `24`]),
            A([`print(10 // 3)`], `3`, [`3.33`, `1`]),
            A([`print(10 % 3)`], `1`, [`3`, `0`]),
            S(
              `Quel opérateur calcule une puissance ?`,
              `§**§`,
              [`§^§`, `§//§`]
            ),
            A([`print(7 / 2)`], `3.5`, [`3`, `4`]),
            S(`Que vaut §5 == 5§ ?`, `§True§`, [`§False§`, `§5§`]),
          ],
        },
      ],
    },
    {
      title: "Unité 2",
      description: "Contrôler le déroulement du programme",
      lessons: [
        {
          title: "Les conditions",
          questions: [
            S(
              `Quel mot-clé démarre une condition ?`,
              `§if§`,
              [`§when§`, `§check§`]
            ),
            A(
              [`x = 5`, `if x > 3:`, `    print("grand")`, `else:`, `    print("petit")`],
              `grand`,
              [`petit`, `Rien ne s'affiche`]
            ),
            S(
              `Que faut-il à la fin de la ligne §if x > 3§ ?`,
              `Deux-points §:§`,
              [`Un point-virgule §;§`, `Une accolade §{§`]
            ),
            S(
              `Comment écrit-on « sinon si » en Python ?`,
              `§elif§`,
              [`§else if§`, `§elseif§`]
            ),
            A(
              [`a = 4`, `if a % 2 == 0:`, `    print("pair")`, `else:`, `    print("impair")`],
              `pair`,
              [`impair`, `0`]
            ),
            S(
              `Quel mot-clé signifie « et » (les deux conditions doivent être vraies) ?`,
              `§and§`,
              [`§&&§`, `§plus§`]
            ),
          ],
        },
        {
          title: "Les boucles for",
          questions: [
            A(
              [`for i in range(3):`, `    print(i)`],
              `0, 1, 2`,
              [`1, 2, 3`, `0, 1, 2, 3`]
            ),
            S(
              `Que produit §range(5)§ ?`,
              `Les nombres de 0 à 4`,
              [`Les nombres de 1 à 5`, `Les nombres de 0 à 5`]
            ),
            A(
              [`for lettre in "abc":`, `    print(lettre)`],
              `a puis b puis c`,
              [`abc d'un coup`, `Une erreur`]
            ),
            S(
              `À quoi sert une boucle §for§ ?`,
              `À répéter des instructions`,
              [`À déclarer une variable`, `À arrêter le programme`]
            ),
            A(
              [`total = 0`, `for n in [1, 2, 3]:`, `    total = total + n`, `print(total)`],
              `6`,
              [`3`, `123`]
            ),
            S(
              `Pourquoi l'indentation est-elle importante en Python ?`,
              `Elle indique quel code appartient au bloc`,
              [`Elle rend le code plus rapide`, `Elle n'a aucun effet`]
            ),
          ],
        },
        {
          title: "Les boucles while",
          questions: [
            S(
              `Une boucle §while§ continue tant que…`,
              `sa condition est vraie`,
              [`elle a fait 10 tours`, `le programme est fermé`]
            ),
            A(
              [`n = 3`, `while n > 0:`, `    print(n)`, `    n = n - 1`],
              `3, 2, 1`,
              [`1, 2, 3`, `Une boucle infinie`]
            ),
            S(
              `Qu'est-ce qu'une boucle infinie ?`,
              `Une boucle dont la condition reste toujours vraie`,
              [`Une boucle qui ne s'exécute jamais`, `Une boucle avec trop de lignes`]
            ),
            S(
              `Quel mot-clé sort immédiatement d'une boucle ?`,
              `§break§`,
              [`§stop§`, `§exit§`]
            ),
            A(
              [`for i in range(5):`, `    if i == 2:`, `        break`, `    print(i)`],
              `0 puis 1`,
              [`0, 1, 2`, `2`]
            ),
            S(
              `Que fait §continue§ dans une boucle ?`,
              `Il passe directement au tour suivant`,
              [`Il arrête la boucle`, `Il relance tout le programme`]
            ),
          ],
        },
        {
          title: "Les fonctions",
          questions: [
            S(
              `Quel mot-clé définit une fonction en Python ?`,
              `§def§`,
              [`§function§`, `§fun§`]
            ),
            A(
              [`def dire_bonjour():`, `    print("Bonjour")`, ``, `dire_bonjour()`],
              `Bonjour`,
              [`Rien ne s'affiche`, `Une erreur`]
            ),
            A(
              [`def double(x):`, `    return x * 2`, ``, `print(double(4))`],
              `8`,
              [`4`, `double(4)`]
            ),
            S(
              `À quoi sert §return§ ?`,
              `À renvoyer une valeur à l'appelant`,
              [`À répéter la fonction`, `À supprimer la fonction`]
            ),
            S(
              `Comment appelle-t-on les valeurs passées entre parenthèses lors d'un appel de fonction ?`,
              `Des arguments`,
              [`Des commentaires`, `Des modules`]
            ),
            A(
              [`def f():`, `    print("A")`, ``, `print("B")`],
              `B seulement`,
              [`A puis B`, `A seulement`]
            ),
          ],
        },
      ],
    },
  ],
};

/* -------------------------------------------------------------------------- */
/*                                 JAVASCRIPT                                 */
/* -------------------------------------------------------------------------- */

const javascript: CourseData = {
  title: "JavaScript",
  imageSrc: "/javascript.svg",
  units: [
    {
      title: "Unité 1",
      description: "Les bases de JavaScript",
      lessons: [
        {
          title: "Premiers pas",
          questions: [
            S(
              `Quelle instruction affiche un message dans la console ?`,
              `§console.log()§`,
              [`§print()§`, `§echo()§`]
            ),
            A([`console.log("Salut");`], `Salut`, [`console.log`, `Une erreur`]),
            S(
              `Comment écrit-on un commentaire sur une ligne en JavaScript ?`,
              `§// commentaire§`,
              [`§# commentaire§`, `§-- commentaire§`]
            ),
            S(
              `Quel caractère termine généralement une instruction JavaScript ?`,
              `§;§`,
              [`§:§`, `§.§`]
            ),
            S(
              `Où JavaScript peut-il s'exécuter ?`,
              `Dans le navigateur (et aussi avec Node.js)`,
              [`Uniquement dans Word`, `Uniquement dans un terminal Linux`]
            ),
            S(
              `JavaScript est-il le même langage que Java ?`,
              `Non, ce sont deux langages différents`,
              [`Oui, c'est le même langage`, `Oui, JavaScript est une version de Java`]
            ),
          ],
        },
        {
          title: "Les variables",
          questions: [
            S(
              `Quel mot-clé déclare une variable modifiable ?`,
              `§let§`,
              [`§variable§`, `§dim§`]
            ),
            S(
              `Quel mot-clé déclare une constante ?`,
              `§const§`,
              [`§final§`, `§fixed§`]
            ),
            A([`let a = 2;`, `a = 5;`, `console.log(a);`], `5`, [`2`, `Une erreur`]),
            A(
              [`const b = 1;`, `b = 2;`],
              `Une erreur`,
              [`b vaut 2`, `b vaut 3`]
            ),
            S(
              `Quel nom suit la convention camelCase ?`,
              `§monScore§`,
              [`§mon_score§`, `§Mon-Score§`]
            ),
            A(
              [`let nom = "Ana";`, `console.log("Salut " + nom);`],
              `Salut Ana`,
              [`Salut nom`, `SalutAna`]
            ),
          ],
        },
        {
          title: "Les types",
          questions: [
            A([`console.log(typeof 42);`], `number`, [`integer`, `int`]),
            A([`console.log(typeof "42");`], `string`, [`number`, `text`]),
            S(
              `Quelles sont les deux valeurs booléennes ?`,
              `§true§ et §false§`,
              [`§True§ et §False§`, `§yes§ et §no§`]
            ),
            A([`console.log("5" + 3);`], `53`, [`8`, `Une erreur`]),
            A([`console.log("5" * 2);`], `10`, [`52`, `Une erreur`]),
            S(
              `Que signifie §undefined§ ?`,
              `Une variable déclarée sans valeur`,
              [`Le nombre zéro`, `Une chaîne vide`]
            ),
          ],
        },
        {
          title: "Les opérateurs",
          questions: [
            A([`console.log(7 % 3);`], `1`, [`2`, `3`]),
            A([`console.log(2 ** 3);`], `8`, [`6`, `5`]),
            S(
              `Quelle est la différence entre §==§ et §===§ ?`,
              `§===§ compare la valeur ET le type`,
              [`Aucune différence`, `§===§ affecte une valeur`]
            ),
            A([`console.log(5 === "5");`], `false`, [`true`, `5`]),
            A([`let n = 1;`, `n++;`, `console.log(n);`], `2`, [`1`, `11`]),
            S(
              `Quel opérateur signifie « ou » ?`,
              `§||§`,
              [`§&&§`, `§!!§`]
            ),
          ],
        },
      ],
    },
    {
      title: "Unité 2",
      description: "Conditions, boucles, tableaux et fonctions",
      lessons: [
        {
          title: "Les conditions",
          questions: [
            S(
              `Quelle syntaxe de condition est correcte en JavaScript ?`,
              `§if (x > 3) { ... }§`,
              [`§if x > 3:§`, `§if [x > 3] then§`]
            ),
            A(
              [`let x = 10;`, `if (x > 5) {`, `  console.log("oui");`, `} else {`, `  console.log("non");`, `}`],
              `oui`,
              [`non`, `Rien ne s'affiche`]
            ),
            S(
              `Quel opérateur signifie « et » ?`,
              `§&&§`,
              [`§||§`, `§and§`]
            ),
            A([`console.log(!true);`], `false`, [`true`, `!true`]),
            S(
              `À quoi sert §else§ ?`,
              `À exécuter du code quand la condition est fausse`,
              [`À répéter du code`, `À déclarer une fonction`]
            ),
            A(
              [`let note = 12;`, `if (note >= 10) console.log("reçu");`],
              `reçu`,
              [`Rien ne s'affiche`, `Une erreur`]
            ),
          ],
        },
        {
          title: "Les boucles",
          questions: [
            A(
              [`for (let i = 0; i < 3; i++) {`, `  console.log(i);`, `}`],
              `0, 1, 2`,
              [`1, 2, 3`, `0, 1, 2, 3`]
            ),
            S(
              `Dans §for (let i = 0; i < 5; i++)§, que fait §i++§ ?`,
              `Il ajoute 1 à i à chaque tour`,
              [`Il initialise i à 0`, `Il arrête la boucle quand i vaut 5`]
            ),
            A(
              [`let n = 3;`, `while (n > 0) {`, `  n--;`, `}`, `console.log(n);`],
              `0`,
              [`3`, `-1`]
            ),
            S(
              `Quel mot-clé arrête une boucle ?`,
              `§break§`,
              [`§stop§`, `§end§`]
            ),
            A(
              [`let s = 0;`, `for (let i = 1; i <= 4; i++) {`, `  s += i;`, `}`, `console.log(s);`],
              `10`,
              [`4`, `24`]
            ),
            S(
              `Quelle boucle parcourt les éléments d'un tableau ?`,
              `§for (const x of tableau)§`,
              [`§for x in range(tableau)§`, `§loop tableau as x§`]
            ),
          ],
        },
        {
          title: "Les tableaux",
          questions: [
            S(
              `Quelle syntaxe crée un tableau ?`,
              `§[1, 2, 3]§`,
              [`§{1, 2, 3}§`, `§(1, 2, 3)§`]
            ),
            A(
              [`const fruits = ["pomme", "kiwi"];`, `console.log(fruits[0]);`],
              `pomme`,
              [`kiwi`, `0`]
            ),
            A([`console.log([4, 5, 6].length);`], `3`, [`6`, `2`]),
            S(
              `Quelle méthode ajoute un élément à la fin d'un tableau ?`,
              `§push()§`,
              [`§add()§`, `§append()§`]
            ),
            A(
              [`const t = [1, 2];`, `t.push(3);`, `console.log(t);`],
              `[1, 2, 3]`,
              [`[3, 1, 2]`, `[1, 2]`]
            ),
            S(
              `Quel est l'indice du premier élément d'un tableau ?`,
              `0`,
              [`1`, `-1`]
            ),
          ],
        },
        {
          title: "Les fonctions",
          questions: [
            S(
              `Quel mot-clé déclare une fonction classique ?`,
              `§function§`,
              [`§def§`, `§func§`]
            ),
            A(
              [`function carre(n) {`, `  return n * n;`, `}`, `console.log(carre(5));`],
              `25`,
              [`10`, `5`]
            ),
            S(
              `Que fait §return§ ?`,
              `Il renvoie une valeur et termine la fonction`,
              [`Il affiche un message`, `Il répète la fonction`]
            ),
            A(
              [`const add = (a, b) => a + b;`, `console.log(add(2, 3));`],
              `5`,
              [`23`, `Une erreur`]
            ),
            S(
              `Comment appelle-t-on §(a, b) => a + b§ ?`,
              `Une fonction fléchée`,
              [`Un tableau`, `Un commentaire`]
            ),
            A(
              [`function f() {`, `  console.log("A");`, `}`, `console.log("B");`],
              `B seulement`,
              [`A puis B`, `A seulement`]
            ),
          ],
        },
      ],
    },
  ],
};

/* -------------------------------------------------------------------------- */
/*                                  HTML / CSS                                */
/* -------------------------------------------------------------------------- */

const htmlCss: CourseData = {
  title: "HTML & CSS",
  imageSrc: "/html.svg",
  units: [
    {
      title: "Unité 1",
      description: "HTML : la structure d'une page web",
      lessons: [
        {
          title: "Premiers pas",
          questions: [
            S(
              `Que signifie HTML ?`,
              `HyperText Markup Language`,
              [`High Tech Modern Language`, `Home Tool Markup Language`]
            ),
            S(
              `Quelle balise crée le plus grand titre ?`,
              `§<h1>§`,
              [`§<h6>§`, `§<header>§`]
            ),
            S(
              `Quelle balise crée un paragraphe ?`,
              `§<p>§`,
              [`§<para>§`, `§<text>§`]
            ),
            S(
              `Comment ferme-t-on la balise §<p>§ ?`,
              `§</p>§`,
              [`§<\\p>§`, `§<p end>§`]
            ),
            A(
              [`<h1>Bonjour</h1>`],
              `Un grand titre « Bonjour »`,
              [`Un paragraphe en gras`, `Un lien vers Bonjour`]
            ),
            S(
              `Quelle balise contient tout le contenu visible de la page ?`,
              `§<body>§`,
              [`§<head>§`, `§<meta>§`]
            ),
          ],
        },
        {
          title: "Texte et listes",
          questions: [
            S(
              `Quelle balise met le texte en gras (importance forte) ?`,
              `§<strong>§`,
              [`§<bold>§`, `§<big>§`]
            ),
            S(
              `Quelle balise crée une liste à puces ?`,
              `§<ul>§`,
              [`§<ol>§`, `§<li>§`]
            ),
            S(
              `Quelle balise crée une liste numérotée ?`,
              `§<ol>§`,
              [`§<ul>§`, `§<nl>§`]
            ),
            S(
              `Quelle balise définit un élément d'une liste ?`,
              `§<li>§`,
              [`§<item>§`, `§<ul>§`]
            ),
            A(
              [`<ul>`, `  <li>Pain</li>`, `  <li>Lait</li>`, `</ul>`],
              `Une liste à puces de 2 éléments`,
              [`Une liste numérotée de 2 éléments`, `Un seul paragraphe`]
            ),
            S(
              `Quelle balise insère un retour à la ligne ?`,
              `§<br>§`,
              [`§<lb>§`, `§<break>§`]
            ),
          ],
        },
        {
          title: "Liens et images",
          questions: [
            S(
              `Quelle balise crée un lien ?`,
              `§<a>§`,
              [`§<link>§`, `§<href>§`]
            ),
            A(
              [`<a href="https://exemple.com">Visiter</a>`],
              `Un lien cliquable qui affiche « Visiter »`,
              [`Une image`, `Un titre`]
            ),
            S(
              `Quel attribut donne l'adresse d'un lien ?`,
              `§href§`,
              [`§src§`, `§url§`]
            ),
            S(
              `Quelle balise affiche une image ?`,
              `§<img>§`,
              [`§<image>§`, `§<pic>§`]
            ),
            S(
              `Quel attribut indique le fichier de l'image ?`,
              `§src§`,
              [`§href§`, `§file§`]
            ),
            S(
              `À quoi sert l'attribut §alt§ d'une image ?`,
              `À décrire l'image (accessibilité)`,
              [`À changer sa taille`, `À la faire bouger`]
            ),
          ],
        },
        {
          title: "Structure d'une page",
          questions: [
            S(
              `Quelle déclaration indique un document HTML5 ?`,
              `§<!DOCTYPE html>§`,
              [`§<html5>§`, `§<?html version=5?>§`]
            ),
            S(
              `Où place-t-on §<title>§ (le titre de l'onglet) ?`,
              `Dans §<head>§`,
              [`Dans §<body>§`, `Dans §<footer>§`]
            ),
            S(
              `Quelle balise est la racine du document ?`,
              `§<html>§`,
              [`§<root>§`, `§<main>§`]
            ),
            S(
              `Quelle balise regroupe le contenu principal de la page ?`,
              `§<main>§`,
              [`§<core>§`, `§<mainpage>§`]
            ),
            S(
              `Quelle balise sert de conteneur générique ?`,
              `§<div>§`,
              [`§<box>§`, `§<block>§`]
            ),
            A(
              [`<html>`, `  <head>`, `    <title>Ma page</title>`, `  </head>`, `  <body></body>`, `</html>`],
              `L'onglet affiche « Ma page »`,
              [`La page affiche « Ma page » en grand titre`, `Une erreur`]
            ),
          ],
        },
      ],
    },
    {
      title: "Unité 2",
      description: "CSS : le style et la mise en page",
      lessons: [
        {
          title: "Les sélecteurs",
          questions: [
            S(
              `Que signifie CSS ?`,
              `Cascading Style Sheets`,
              [`Computer Style Software`, `Creative Simple Syntax`]
            ),
            A(
              [`p {`, `  color: red;`, `}`],
              `Tous les paragraphes sont en rouge`,
              [`Le premier titre est en rouge`, `Tous les liens sont en rouge`]
            ),
            S(
              `Quel sélecteur cible la classe §titre§ ?`,
              `§.titre§`,
              [`§#titre§`, `§*titre§`]
            ),
            S(
              `Quel sélecteur cible l'élément d'id §menu§ ?`,
              `§#menu§`,
              [`§.menu§`, `§@menu§`]
            ),
            S(
              `Quel attribut HTML associe une classe à un élément ?`,
              `§class§`,
              [`§type§`, `§css§`]
            ),
            S(
              `Quelle déclaration CSS est correcte ?`,
              `§color: blue;§`,
              [`§color = blue§`, `§color -> blue§`]
            ),
          ],
        },
        {
          title: "Couleurs et texte",
          questions: [
            S(
              `Quelle propriété change la couleur du texte ?`,
              `§color§`,
              [`§text-color§`, `§font-color§`]
            ),
            S(
              `Quelle propriété change la couleur de fond ?`,
              `§background-color§`,
              [`§bgcolor§`, `§back-color§`]
            ),
            S(
              `Quelle propriété change la taille du texte ?`,
              `§font-size§`,
              [`§text-size§`, `§size§`]
            ),
            A(
              [`h1 {`, `  text-align: center;`, `}`],
              `Le titre est centré`,
              [`Le titre est en gras`, `Le titre disparaît`]
            ),
            S(
              `Quel format de couleur est valide ?`,
              `§#ff0000§`,
              [`§ff0000#§`, `§rgb[255,0,0]§`]
            ),
            S(
              `Quelle propriété met le texte en gras ?`,
              `§font-weight§`,
              [`§text-bold§`, `§font-bold§`]
            ),
          ],
        },
        {
          title: "Le modèle de boîte",
          questions: [
            S(
              `Quelle propriété ajoute de l'espace à l'intérieur d'une boîte ?`,
              `§padding§`,
              [`§margin§`, `§border§`]
            ),
            S(
              `Quelle propriété ajoute de l'espace à l'extérieur d'une boîte ?`,
              `§margin§`,
              [`§padding§`, `§content§`]
            ),
            A(
              [`div {`, `  border: 2px solid black;`, `}`],
              `Un cadre noir de 2 pixels autour du div`,
              [`Un fond noir`, `Un texte de 2 pixels`]
            ),
            S(
              `Quel est l'ordre du centre vers l'extérieur dans le modèle de boîte ?`,
              `Contenu, padding, bordure, margin`,
              [`Contenu, margin, bordure, padding`, `Bordure, contenu, margin, padding`]
            ),
            S(
              `Quelle propriété arrondit les coins ?`,
              `§border-radius§`,
              [`§corner-round§`, `§round§`]
            ),
            A(
              [`.carte {`, `  width: 200px;`, `  height: 100px;`, `}`],
              `Une boîte de 200 px de large sur 100 px de haut`,
              [`Une boîte de 100 px de large sur 200 px de haut`, `Un texte de 200 px`]
            ),
          ],
        },
        {
          title: "Flexbox",
          questions: [
            S(
              `Quelle déclaration active Flexbox sur un conteneur ?`,
              `§display: flex;§`,
              [`§flex: container;§`, `§layout: flex;§`]
            ),
            S(
              `Quelle propriété aligne les éléments sur l'axe principal ?`,
              `§justify-content§`,
              [`§text-align§`, `§float§`]
            ),
            A(
              [`.menu {`, `  display: flex;`, `  flex-direction: column;`, `}`],
              `Les éléments sont empilés verticalement`,
              [`Les éléments sont côte à côte`, `Les éléments disparaissent`]
            ),
            S(
              `Quelle propriété espace les éléments d'un conteneur flex ?`,
              `§gap§`,
              [`§space§`, `§between§`]
            ),
            S(
              `Quelle valeur de §justify-content§ répartit l'espace entre les éléments ?`,
              `§space-between§`,
              [`§stretch-all§`, `§distribute§`]
            ),
            S(
              `Quelle propriété centre les éléments sur l'axe secondaire ?`,
              `§align-items§`,
              [`§text-center§`, `§center-items§`]
            ),
          ],
        },
      ],
    },
  ],
};

// Unités supplémentaires (ajoutées à la fin de chaque cours).
python.units.push(...pythonMore);
javascript.units.push(...javascriptMore);
htmlCss.units.push(...htmlCssMore);

export const curriculum: CourseData[] = [python, javascript, htmlCss];
