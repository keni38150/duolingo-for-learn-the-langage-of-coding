import { create } from "zustand";
import { persist } from "zustand/middleware";

import { MAX_HEARTS, POINTS_TO_REFILL } from "@/constants";

type ActionResult = { error?: "hearts" | "practice" } | undefined;

type ProgressState = {
  activeCourseId: number | null;
  hearts: number;
  points: number;
  completed: Record<number, true>;
  setActiveCourse: (courseId: number) => void;
  completeChallenge: (challengeId: number) => ActionResult;
  loseHeart: (challengeId: number) => ActionResult;
  refillHearts: () => void;
  reset: () => void;
};

const initialState = {
  activeCourseId: null,
  hearts: MAX_HEARTS,
  points: 0,
  completed: {} as Record<number, true>,
};

// La progression est sauvegardée dans le localStorage du navigateur.
export const useProgress = create<ProgressState>()(
  persist(
    (set, get) => ({
      ...initialState,

      setActiveCourse: (courseId) => set({ activeCourseId: courseId }),

      completeChallenge: (challengeId) => {
        const { hearts, points, completed } = get();
        const isPractice = !!completed[challengeId];

        if (hearts === 0 && !isPractice) return { error: "hearts" };

        if (isPractice) {
          set({
            hearts: Math.min(hearts + 1, MAX_HEARTS),
            points: points + 10,
          });
          return;
        }

        set({
          points: points + 10,
          completed: { ...completed, [challengeId]: true },
        });
      },

      loseHeart: (challengeId) => {
        const { hearts, completed } = get();

        if (completed[challengeId]) return { error: "practice" };
        if (hearts === 0) return { error: "hearts" };

        set({ hearts: Math.max(hearts - 1, 0) });
      },

      refillHearts: () => {
        const { hearts, points } = get();

        if (hearts === MAX_HEARTS || points < POINTS_TO_REFILL) return;

        set({ hearts: MAX_HEARTS, points: points - POINTS_TO_REFILL });
      },

      reset: () => set({ ...initialState, completed: {} }),
    }),
    {
      name: "lingo-code-progress",
      version: 1,
      partialize: (state) => ({
        activeCourseId: state.activeCourseId,
        hearts: state.hearts,
        points: state.points,
        completed: state.completed,
      }),
    }
  )
);
