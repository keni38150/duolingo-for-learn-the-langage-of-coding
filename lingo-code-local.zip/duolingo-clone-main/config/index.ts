import type { Metadata } from "next";

export const siteConfig: Metadata = {
  title: "Lingo Code",
  description:
    "Apprends à coder (Python, JavaScript, HTML & CSS) avec des leçons, des quiz et un suivi de progression.",
};
