import { useEffect, useState } from "react";

// Vrai uniquement côté navigateur, après le premier rendu.
// Évite les différences entre le HTML serveur et la progression sauvegardée.
export const useMounted = () => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  return mounted;
};
