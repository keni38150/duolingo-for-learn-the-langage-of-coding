import { useEffect } from "react";

import { useRouter } from "next/navigation";

import { getCourseById } from "@/lib/catalog";
import { useProgress } from "@/store/use-progress";

import { useMounted } from "./use-mounted";

// Attend le chargement de la progression et renvoie vers /courses
// tant qu'aucun cours n'a été choisi.
export const useProgressGate = () => {
  const router = useRouter();
  const mounted = useMounted();

  const activeCourseId = useProgress((s) => s.activeCourseId);
  const hearts = useProgress((s) => s.hearts);
  const points = useProgress((s) => s.points);

  const activeCourse = activeCourseId
    ? getCourseById(activeCourseId)
    : undefined;

  useEffect(() => {
    if (mounted && !activeCourse) router.replace("/courses");
  }, [mounted, activeCourse, router]);

  return { ready: mounted && !!activeCourse, activeCourse, hearts, points };
};
