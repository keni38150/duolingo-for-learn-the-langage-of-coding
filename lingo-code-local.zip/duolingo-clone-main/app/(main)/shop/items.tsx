"use client";

import Image from "next/image";

import { Button } from "@/components/ui/button";
import { MAX_HEARTS, POINTS_TO_REFILL } from "@/constants";
import { useProgress } from "@/store/use-progress";

type ItemsProps = {
  hearts: number;
  points: number;
};

export const Items = ({ hearts, points }: ItemsProps) => {
  const refillHearts = useProgress((s) => s.refillHearts);

  const disabled = hearts === MAX_HEARTS || points < POINTS_TO_REFILL;

  return (
    <ul className="w-full">
      <li className="flex w-full items-center gap-x-4 border-t-2 p-4">
        <Image src="/heart.svg" alt="Cœur" height={60} width={60} />

        <div className="flex-1">
          <p className="text-base font-bold text-neutral-700 lg:text-xl">
            Recharger les cœurs
          </p>
        </div>

        <Button
          onClick={refillHearts}
          disabled={disabled}
          aria-disabled={disabled}
        >
          {hearts === MAX_HEARTS ? (
            "plein"
          ) : (
            <div className="flex items-center">
              <Image src="/points.svg" alt="Points" height={20} width={20} />

              <p>{POINTS_TO_REFILL}</p>
            </div>
          )}
        </Button>
      </li>
    </ul>
  );
};
