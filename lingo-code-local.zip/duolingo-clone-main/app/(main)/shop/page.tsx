"use client";

import Image from "next/image";

import { FeedWrapper } from "@/components/feed-wrapper";
import { Quests } from "@/components/quests";
import { StickyWrapper } from "@/components/sticky-wrapper";
import { UserProgress } from "@/components/user-progress";
import { useProgressGate } from "@/hooks/use-progress-gate";

import { Items } from "./items";

const ShopPage = () => {
  const { ready, activeCourse, hearts, points } = useProgressGate();

  if (!ready || !activeCourse) return null;

  return (
    <div className="flex flex-row-reverse gap-[48px] px-6">
      <StickyWrapper>
        <UserProgress
          activeCourse={activeCourse}
          hearts={hearts}
          points={points}
        />

        <Quests points={points} />
      </StickyWrapper>

      <FeedWrapper>
        <div className="flex w-full flex-col items-center">
          <Image src="/shop.svg" alt="Boutique" height={90} width={90} />

          <h1 className="my-6 text-center text-2xl font-bold text-neutral-800">
            Boutique
          </h1>
          <p className="mb-6 text-center text-lg text-muted-foreground">
            Dépense tes points pour recharger tes cœurs.
          </p>

          <Items hearts={hearts} points={points} />
        </div>
      </FeedWrapper>
    </div>
  );
};

export default ShopPage;
