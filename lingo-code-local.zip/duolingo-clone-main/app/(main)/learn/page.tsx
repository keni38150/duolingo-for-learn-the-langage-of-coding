"use client";

import { FeedWrapper } from "@/components/feed-wrapper";
import { Quests } from "@/components/quests";
import { StickyWrapper } from "@/components/sticky-wrapper";
import { UserProgress } from "@/components/user-progress";
import { useProgressGate } from "@/hooks/use-progress-gate";
import { getUnitsByCourse } from "@/lib/catalog";
import { useProgress } from "@/store/use-progress";

import { Header } from "./header";
import { Unit } from "./unit";

const LearnPage = () => {
  const { ready, activeCourse, hearts, points } = useProgressGate();
  const completed = useProgress((s) => s.completed);

  if (!ready || !activeCourse) return null;

  const units = getUnitsByCourse(activeCourse.id).map((unit) => ({
    ...unit,
    lessons: unit.lessons.map((lesson) => ({
      ...lesson,
      completed:
        lesson.challengeIds.length > 0 &&
        lesson.challengeIds.every((id) => completed[id]),
    })),
  }));

  const activeLesson = units
    .flatMap((unit) => unit.lessons)
    .find((lesson) => !lesson.completed);

  const activeLessonPercentage = activeLesson
    ? Math.round(
        (activeLesson.challengeIds.filter((id) => completed[id]).length /
          activeLesson.challengeIds.length) *
          100
      )
    : 0;

  return (
    <div className="flex flex-row-reverse gap-[48px] px-6">
      <StickyWrapper>
        <UserProgress
          activeCourse={activeCourse}
          hearts={hearts}
          points={points}
        />

        <Quests points={points} />
      </StickyWrapper>

      <FeedWrapper>
        <Header title={activeCourse.title} />

        {units.map((unit) => (
          <div key={unit.id} className="mb-10">
            <Unit
              title={unit.title}
              description={unit.description}
              lessons={unit.lessons}
              activeLesson={activeLesson}
              activeLessonPercentage={activeLessonPercentage}
            />
          </div>
        ))}
      </FeedWrapper>
    </div>
  );
};

export default LearnPage;
