"use client";

import { useMounted } from "@/hooks/use-mounted";
import { getCourses } from "@/lib/catalog";
import { useProgress } from "@/store/use-progress";

import { List } from "./list";

const CoursesPage = () => {
  const mounted = useMounted();
  const activeCourseId = useProgress((s) => s.activeCourseId);

  return (
    <div className="mx-auto h-full max-w-[912px] px-3">
      <h1 className="text-2xl font-bold text-neutral-700">
        Cours de programmation
      </h1>

      {mounted && (
        <List courses={getCourses()} activeCourseId={activeCourseId} />
      )}
    </div>
  );
};

export default CoursesPage;
