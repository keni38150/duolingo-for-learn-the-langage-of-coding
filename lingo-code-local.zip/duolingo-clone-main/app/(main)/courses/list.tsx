"use client";

import { useRouter } from "next/navigation";

import type { Course } from "@/lib/types";
import { useProgress } from "@/store/use-progress";

import { Card } from "./card";

type ListProps = {
  courses: Course[];
  activeCourseId: number | null;
};

export const List = ({ courses, activeCourseId }: ListProps) => {
  const router = useRouter();
  const setActiveCourse = useProgress((s) => s.setActiveCourse);

  const onClick = (id: number) => {
    setActiveCourse(id);
    router.push("/learn");
  };

  return (
    <div className="grid grid-cols-2 gap-4 pt-6 lg:grid-cols-[repeat(auto-fill,minmax(210px,1fr))]">
      {courses.map((course) => (
        <Card
          key={course.id}
          id={course.id}
          title={course.title}
          imageSrc={course.imageSrc}
          onClick={onClick}
          isActive={course.id === activeCourseId}
        />
      ))}
    </div>
  );
};
