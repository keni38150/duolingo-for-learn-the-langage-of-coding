import { LessonLoader } from "../lesson-loader";

type LessonIdPageProps = {
  params: Promise<{
    lessonId: string;
  }>;
};

const LessonIdPage = async ({ params }: LessonIdPageProps) => {
  const { lessonId } = await params;

  return <LessonLoader lessonId={Number(lessonId)} />;
};

export default LessonIdPage;
