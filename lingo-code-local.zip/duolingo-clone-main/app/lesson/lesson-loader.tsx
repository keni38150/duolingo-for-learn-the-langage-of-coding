"use client";

import { useEffect, useState } from "react";

import { useRouter } from "next/navigation";

import { useMounted } from "@/hooks/use-mounted";
import { getLessonById, getUnitsByCourse } from "@/lib/catalog";
import { useProgress } from "@/store/use-progress";

import { Quiz } from "./quiz";

type LessonLoaderProps = {
  lessonId?: number;
};

const shuffle = <T,>(items: T[]): T[] => {
  const result = [...items];

  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }

  return result;
};

const LessonContent = ({ lessonId }: LessonLoaderProps) => {
  const router = useRouter();

  // Calculé une seule fois : la progression enregistrée pendant le quiz
  // ne doit pas recharger la leçon en cours de route.
  const [data] = useState(() => {
    const { activeCourseId, completed, hearts } = useProgress.getState();

    if (!activeCourseId) return null;

    let id = lessonId;

    if (!id) {
      id = getUnitsByCourse(activeCourseId)
        .flatMap((unit) => unit.lessons)
        .find(
          (lesson) =>
            !lesson.challengeIds.every((challengeId) => completed[challengeId])
        )?.id;
    }

    const lesson = id ? getLessonById(id) : undefined;

    if (!lesson) return null;

    const challenges = lesson.challenges.map((challenge) => ({
      ...challenge,
      completed: !!completed[challenge.id],
      challengeOptions: shuffle(challenge.challengeOptions),
    }));

    const completedCount = challenges.filter((c) => c.completed).length;

    return {
      lessonId: lesson.id,
      challenges,
      hearts,
      initialPercentage:
        challenges.length === 0
          ? 0
          : (completedCount / challenges.length) * 100,
    };
  });

  useEffect(() => {
    if (!data) router.replace("/learn");
  }, [data, router]);

  if (!data) return null;

  return (
    <Quiz
      initialLessonId={data.lessonId}
      initialLessonChallenges={data.challenges}
      initialHearts={data.hearts}
      initialPercentage={data.initialPercentage}
    />
  );
};

export const LessonLoader = ({ lessonId }: LessonLoaderProps) => {
  const mounted = useMounted();

  if (!mounted) return null;

  return <LessonContent lessonId={lessonId} />;
};
