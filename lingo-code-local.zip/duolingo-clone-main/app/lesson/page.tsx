import { LessonLoader } from "./lesson-loader";

const LessonPage = () => {
  return <LessonLoader />;
};

export default LessonPage;
