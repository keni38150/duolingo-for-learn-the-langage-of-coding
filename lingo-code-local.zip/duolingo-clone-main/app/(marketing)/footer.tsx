import Image from "next/image";

import { Button } from "@/components/ui/button";

const COURSES = [
  { src: "/python.svg", name: "Python" },
  { src: "/javascript.svg", name: "JavaScript" },
  { src: "/html.svg", name: "HTML & CSS" },
];

export const Footer = () => {
  return (
    <div className="hidden h-20 w-full border-t-2 border-slate-200 p-2 lg:block">
      <div className="mx-auto flex h-full max-w-screen-lg items-center justify-evenly">
        {COURSES.map((course) => (
          <Button
            key={course.name}
            size="lg"
            variant="ghost"
            className="w-full cursor-default"
          >
            <Image
              src={course.src}
              alt={course.name}
              height={32}
              width={40}
              className="mr-4 rounded-md"
            />
            {course.name}
          </Button>
        ))}
      </div>
    </div>
  );
};
